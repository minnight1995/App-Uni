import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/pages/perfil_page.dart';
import 'package:unibuddy/pages/agenda_page.dart';
import 'package:unibuddy/pages/home_page.dart';
import 'package:unibuddy/pages/materias_page.dart';

class BarraNavegacion extends StatelessWidget {
  final int indice;
  final ValueChanged<int>? onCambiar;

  const BarraNavegacion({
    super.key,
    required this.indice,
    this.onCambiar,
  });
  void _ir(BuildContext context, int i){
    if(i == indice) return;
    if(onCambiar != null){
      onCambiar!(i);
      return;
    }
    Widget destino;
    switch (i) {
      case 0:
        destino = HomePage();
        break;
      case 1:
        destino = MateriasPage();
        break;
      case 2:
        destino = AgendaPage();
        break;
      default:
        destino = PerfilPage();
    }


    Navigator.pushReplacement(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => destino,
        transitionDuration: Duration.zero,
        reverseTransitionDuration: Duration.zero,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        boxShadow: [
          BoxShadow(
            color: Color(0xFF7957EA).withOpacity(0.20),
            blurRadius: 18,
            offset: Offset(0, -4),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: EdgeInsets.fromLTRB(12, 10, 12, 8),
          child: Row(
            children: [
              _Item(
                icono: Icons.home_outlined,
                iconoActivo: Icons.home_rounded,
                texto: "Inicio",
                activo: indice == 0,
                onTap: () => _ir(context, 0),
              ),

              _Item(
                icono: Icons.menu_book_outlined,
                iconoActivo: Icons.menu_book_rounded,
                texto: "Materias",
                activo: indice == 1,
                onTap: () => _ir(context, 1),
              ),

              _Item(
                icono: Icons.calendar_month_outlined,
                iconoActivo: Icons.calendar_month_rounded,
                texto: "Agenda",
                activo: indice == 2,
                onTap: () => _ir(context, 2),
              ),

              _Item(
                icono: Icons.person_outline_rounded,
                iconoActivo: Icons.person_rounded,
                texto: "Perfil",
                activo: indice == 3,
                onTap: () => _ir(context, 3),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
class _Item extends StatelessWidget{
  final IconData icono;
  final IconData iconoActivo;
  final String texto;
  final bool activo;
  final VoidCallback onTap;

  const _Item({
    required this.icono,
    required this.iconoActivo,
    required this.texto,
    required this.activo,
    required this.onTap,
  });
  @override
  Widget build(BuildContext context) {
    final color = activo ? Color(0xFF5B2CE0) : Color(0xFF7B5CD6);

    return Expanded(
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: onTap,
          child: Container(
            margin: EdgeInsets.symmetric(horizontal: 4),
            padding: EdgeInsets.symmetric(vertical: 8),
            decoration: BoxDecoration(
              color: activo ? Color(0xFFEDE4FA) : Colors.transparent,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(activo ? iconoActivo : icono, size: 30, color: color),

                SizedBox(height: 4),
                Text(texto,
                  style: GoogleFonts.poppins(fontSize: 12, fontWeight: activo ? FontWeight.w700 : FontWeight.w500,
                      color: activo ? Color(0xFF35147D) : color),
                ),
              ],
            ),
          ),
        )
    );
  }
}