import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/utilidades/agenda.dart';
import 'package:unibuddy/utilidades/materias.dart';

class BarraDias extends StatelessWidget {
  final DateTime hoy;
  final int seleccionado;
  final ValueChanged<int> onDia;

  const BarraDias({
    super.key,
    required this.hoy,
    required this.seleccionado,
    required this.onDia,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 78,
      margin: EdgeInsets.only(bottom: 12),
      padding: EdgeInsets.symmetric(vertical: 16),
      decoration: BoxDecoration(
        color: Color(0xFF35147D),
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(28),
          bottomLeft: Radius.circular(28),
        ),
      ),
      child: SingleChildScrollView(
        child: Column(
          children: [
            Text("Hoy",
                style: GoogleFonts.poppins(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.white70)
            ),
            Text(nombresdias[hoy.weekday - 1],
                style: GoogleFonts.poppins(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.white)
            ),
            Text("${hoy.day}",
                style: GoogleFonts.fredoka(fontSize: 34, fontWeight: FontWeight.w700, color: Colors.white)
            ),
            Text(meses[hoy.month - 1],
                style: GoogleFonts.poppins(fontSize: 13, fontWeight: FontWeight.w600, color: Colors.white)
            ),

            SizedBox(height: 18),
            ...List.generate(7, (i){
            final dia = i + 1;
            final sel = dia == seleccionado;
            final eshoy = dia == hoy.weekday;

            return GestureDetector(
              onTap: () => onDia(dia),
              child: AnimatedContainer(
                  duration: Duration(milliseconds: 200),
                margin: EdgeInsets.only(bottom: 8),
                width: 48,
                height: 44,
                decoration: BoxDecoration(
                  color: sel
                      ?Color(0xFF7B5CD6)
                      :eshoy
                      ?Colors.white
                      :Colors.white.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(letrasdias[i],
                      style: GoogleFonts.poppins(fontSize: 17, fontWeight: FontWeight.w700,
                        color: sel
                            ? Colors.white
                            : eshoy
                            ? Color(0xFF35147D)
                            : Colors.white,
                      ),
                    ),
                    if (eshoy)
                      Container(
                        width: 16,
                        height: 3,
                        margin: EdgeInsets.only(top: 2),
                        decoration: BoxDecoration(
                          color: sel
                              ? Colors.white
                              : Color(0xFF7B5CD6),
                          borderRadius: BorderRadius.circular(3),
                        ),
                      ),
                  ],
                ),
              ),
            );
            })
          ],
        ),
      ),
    );
  }
}
