import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class BarraBusqueda extends StatelessWidget {
  final String hint;
  final TextEditingController? control;
  final ValueChanged<String>? onCambio;
  final VoidCallback? onAgregar;

  const BarraBusqueda({
    super.key,
    this.hint = "Buscar materia...",
    this.control,
    this.onCambio,
    this.onAgregar,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: Color(0xFFE4D9F7),
                borderRadius: BorderRadius.circular(30),
              ),
              child: Row(
                children: [
                  Icon(Icons.search_rounded, color: Color(0xFF7B5CD6), size: 24),

                  SizedBox(width: 10),
                  Expanded(
                      child: TextField(
                        controller: control,
                        onChanged: onCambio,
                        style: GoogleFonts.poppins(fontSize: 15, fontWeight: FontWeight.w500, color: Color(0xFF35147D)),
                        decoration: InputDecoration(
                          hintText: hint,
                          hintStyle: GoogleFonts.poppins(fontSize: 15, fontWeight: FontWeight.w500, color: Color(0xFF5245AE)),
                          border: InputBorder.none,
                          isDense: true,
                          contentPadding: EdgeInsets.symmetric(vertical: 14),
                        ),
                      ),
                  ),
                ],
              ),
            )
        ),

        SizedBox(width: 12),
        InkWell(
          customBorder: CircleBorder(),
          onTap: onAgregar,
          child: Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF9675E8), Color(0xFF6A3FD9)],
              ),
              boxShadow: [
                BoxShadow(
                  color: Color(0xFF7B5CD6).withOpacity(0.4),
                  blurRadius: 10,
                  offset: Offset(0, 5),
                )
              ]
            ),
            child: Icon(Icons.add_rounded, color: Colors.white, size: 30),
          ),
        )
      ],
    );
  }
}
