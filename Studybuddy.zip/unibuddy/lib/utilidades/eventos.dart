import 'package:flutter/material.dart';
import 'package:unibuddy/utilidades/agenda.dart';

class CategoriaAgenda {
  final String nombre;
  final Color color;
  final IconData icono;
  const CategoriaAgenda(this.nombre, this.color, this.icono);
}

const List<CategoriaAgenda> categoriasagenda = [
  CategoriaAgenda("Clase", Color(0xFF7B5CD6), Icons.school_rounded),
  CategoriaAgenda("Actividad académica", Color(0xFF3FA66B), Icons.assignment_turned_in_rounded),
  CategoriaAgenda("Estudio", Color(0xFFE8A317), Icons.auto_stories_rounded),
  CategoriaAgenda("Taller", Color(0xFF4DA6F5), Icons.handyman_rounded),
  CategoriaAgenda("Otro", Color(0xFFD16BA5), Icons.event_rounded),
];

enum OrigenItem { clase, evento }

class ItemAgenda {
final OrigenItem origen;
final int id;
final String titulo;
final String subtitulo;
final int categoria;
final Color color;
final DateTime inicio;
final DateTime? fin;
final String lugar;
final String descripcion;
final Map<String, dynamic> datos;

const ItemAgenda({
required this.origen,
required this.id,
required this.titulo,
required this.subtitulo,
required this.categoria,
required this.color,
required this.inicio,
required this.fin,
required this.lugar,
required this.descripcion,
required this.datos,
});

bool get esclase => origen == OrigenItem.clase;

String get horario => fin == null
    ? horaampm(inicio)
    : '${horaampm(inicio)} – ${horaampm(fin!)}';
}

DateTime combinarhora(DateTime dia, String hhmm) {
  final p = hhmm.split(':');
  return DateTime(
      dia.year, dia.month, dia.day, int.parse(p[0]), int.parse(p[1]));
}

List<ItemAgenda> itemsdeldia({
  required DateTime dia,
  required List<Map<String, dynamic>> clases,
  required List<Map<String, dynamic>> materias,
  required List<Map<String, dynamic>> eventos,
}) {
  final items = <ItemAgenda>[];

  for (final c in clases) {
    if (c["dia"] != dia.weekday) continue;

    Map<String, dynamic>? m;
    for (final x in materias) {
      if (x["id"] == c["materia_id"]) {
        m = x;
        break;
      }
    }
    if (m == null) continue;

    final salon = (c["salon"] ?? "").toString();
    items.add(ItemAgenda(
      origen: OrigenItem.clase,
      id: c["id"],
      titulo: m["nombre"],
      subtitulo: salon.isEmpty ? "Clase" : "Clase · $salon",
      categoria: 0,
      color: Color(m['color']),
      inicio: combinarhora(dia, c["inicio"]),
      fin: combinarhora(dia, c["fin"]),
      lugar: salon,
      descripcion: (m["descripcion"] ?? "").toString(),
      datos: c,
    ));
  }

  for (final e in eventos) {
    final inicio = e["inicio"] as DateTime;
    if (!mismodia(inicio, dia)) continue;

    final cat = (e["categoria"] is int &&
        e["categoria"] >= 0 &&
        e["categoria"] < categoriasagenda.length)
        ? e["categoria"] as int
        : categoriasagenda.length - 1;

    items.add(ItemAgenda(
      origen: OrigenItem.evento,
      id: e["id"],
      titulo: e["titulo"],
      subtitulo: categoriasagenda[cat].nombre,
      categoria: cat,
      color: categoriasagenda[cat].color,
      inicio: inicio,
      fin: e["fin"] as DateTime?,
      lugar: (e["lugar"] ?? "").toString(),
      descripcion: (e["descripcion"] ?? "").toString(),
      datos: e,
    ));
  }

  items.sort((a, b) => a.inicio.compareTo(b.inicio));
  return items;
}