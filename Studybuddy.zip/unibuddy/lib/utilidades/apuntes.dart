import 'package:flutter/material.dart';

const List<List<Color>> paletaapuntes = [
  [Color(0xFFE4D9F7), Color(0xFF7B5CD6)],
  [Color(0xFFF8D9EC), Color(0xFFD16BA5)],
  [Color(0xFFD5F0DF), Color(0xFF3FA66B)],
  [Color(0xFFD9E8FB), Color(0xFF4DA6F5)],
  [Color(0xFFFFE8CC), Color(0xFFE8A317)],
];

