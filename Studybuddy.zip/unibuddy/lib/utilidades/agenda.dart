import 'package:flutter/material.dart';
import 'package:unibuddy/utilidades/materias.dart';

const nombresdias = [
  'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo',
];
const letrasdias = ['L', 'M', 'M', 'J', 'V', 'S', 'D'];
const diascortos = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];

String horatexto(TimeOfDay t) {
  final h = t.hour.toString().padLeft(2, '0');
  final m = t.minute.toString().padLeft(2, '0');
  return '$h:$m';
}

const mesescompletos = [
  'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
  'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre',
];

bool mismodia(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month && a.day == b.day;

DateTime sumardias(DateTime d, int n) =>
    DateTime(d.year, d.month, d.day + n);

DateTime lunesdelasemana(DateTime d) =>
    DateTime(d.year, d.month, d.day - (d.weekday - 1));

String horaampm(DateTime d) {
  final h = d.hour % 12 == 0 ? 12 : d.hour % 12;
  final min = d.minute.toString().padLeft(2, '0');
  return '$h:$min ${d.hour < 12 ? 'AM' : 'PM'}';
}

String fechadia(DateTime d) => '${d.day} de ${mesescompletos[d.month - 1]}';

String fechalarga(DateTime d) =>
    '${nombresdias[d.weekday - 1]}, ${fechadia(d)}';

String mesyanio(DateTime d) {
  final mes = mesescompletos[d.month - 1];
  return '${mes[0].toUpperCase()}${mes.substring(1)} ${d.year}';
}

String rangosemana(DateTime lunes) {
  final fin = sumardias(lunes, 6);
  final m1 = meses[lunes.month - 1];
  final m2 = meses[fin.month - 1];
  return lunes.month == fin.month
      ? '${lunes.day} - ${fin.day} $m2'
      : '${lunes.day} $m1 - ${fin.day} $m2';
}