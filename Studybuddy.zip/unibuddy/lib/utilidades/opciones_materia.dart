import 'package:flutter/material.dart';

const List<IconData> listaiconos = [
  Icons.school, Icons.storage, Icons.calculate, Icons.science,
  Icons.code, Icons.menu_book, Icons.language, Icons.brush,
  Icons.biotech, Icons.computer, Icons.music_note, Icons.history_edu,
];

const List<Color> listacolores = [
  Color(0xFF7C5CE6), Color(0xFF4DA6F5), Color(0xFF5CC08A),
  Color(0xFFFFA726), Color(0xFFD27FF0), Color(0xFFFF8FB1),
];