import 'package:flutter/material.dart';
import 'package:unibuddy/api.dart';

const meses = [
  'Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun',
  'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic',
];

String formatearfecha(DateTime f) {
  final h = f.hour % 12 == 0 ? 12 : f.hour % 12;
  final min = f.minute.toString().padLeft(2, '0');
  final ampm = f.hour < 12 ? 'AM' : 'PM';
  return '${f.day} ${meses[f.month - 1]} • $h:$min $ampm';
}

String fechacorta(DateTime f) {
  return '${f.day} ${meses[f.month - 1]}';
}


Color colorprioridad(String p) {
  switch (p) {
    case 'Alta':
      return const Color(0xFFE0457B);
    case 'Media':
      return const Color(0xFFE8A317);
    default:
      return const Color(0xFF3FA66B);
  }
}

Future<void> completartarea(
    Map<String, dynamic> t, VoidCallback refrescar) async {
  t['completada'] = true;
  refrescar();

  final token = await leerToken();
  if (token == null) return;

  final r = await marcarTarea(token, t['id'], true);
  if (r.containsKey('error')) {
    t['completada'] = false;
    refrescar();
  }
}


