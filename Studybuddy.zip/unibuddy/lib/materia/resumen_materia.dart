import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/accesos/pomodoro_page.dart';
import 'package:unibuddy/cartas/carta_proxtareas.dart';
import 'package:unibuddy/api.dart';
import 'package:unibuddy/pages/tareas_page.dart';
import 'package:unibuddy/utilidades/materias.dart';


class ResumenMateria extends StatefulWidget {
  final Map<String, dynamic> materia;
  final List<Map<String, dynamic>> tareas;
  final VoidCallback onCambio;

  const ResumenMateria({
    super.key,
    required this.materia,
    required this.tareas,
    required this.onCambio,
  });

  @override
  State<ResumenMateria> createState() => _ResumenMateriaState();
}

class _ResumenMateriaState extends State<ResumenMateria> {
  static const morado = Color(0xFF4A2FBD);
  static const moradoOscuro = Color(0xFF35147D);
  final descripcion_control = TextEditingController();
  final _foco = FocusNode();
  String _ultimoguardado = '';

  @override
  void initState(){
    super.initState();
    _ultimoguardado = (widget.materia["descripcion"] ?? '').toString();
    descripcion_control.text =  _ultimoguardado;
    _foco.addListener(() {
      if (!_foco.hasFocus) _guardar();
    });
  }

  Future<void> _guardar() async {
    final texto = descripcion_control.text.trim();
    if (texto == _ultimoguardado) return;

    final anterior = _ultimoguardado;
    _ultimoguardado = texto;

    widget.materia["descripcion"] = texto;

    final token = await leerToken();
    if (token == null) return;

    final r = await guardarDescripcion(token, widget.materia["id"], texto);
    if (r.containsKey("error")) {
      _ultimoguardado = anterior;
    }
  }

  List<Map<String, dynamic>> _proximas() {
    final limite = DateTime.now().add(const Duration(days: 7));
    final lista = widget.tareas
        .where((t) => t["completada"] != true && (t["fecha"] as DateTime).isBefore(limite)).toList()
      ..sort((a, b) => (a["fecha"] as DateTime).compareTo(b["fecha"] as DateTime));
    return lista.take(3).toList();
  }

  Future<void> _vertodas() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TareasPage(
          materiaId: widget.materia['id'],
          tareas: widget.tareas,
        ),
      ),
    );
    widget.onCambio();
  }

  @override
  void dispose() {
    _guardar();
    _foco.dispose();
    descripcion_control.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final proximas = _proximas();

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Información",
          style: GoogleFonts.fredoka(fontSize: 20, fontWeight: FontWeight.w700, color: moradoOscuro),
          ),

          SizedBox(height: 10),
          Container(
            padding: EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(
                    color: const Color(0xFFE4D9F7),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(Icons.menu_book_rounded, color: morado),
                ),

                SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    controller: descripcion_control,
                    focusNode: _foco,
                    onTapOutside: (_) => FocusScope.of(context).unfocus(),
                    minLines: 2,
                    maxLines: 4,
                    style: GoogleFonts.poppins(fontSize: 15, fontWeight: FontWeight.w500, color: moradoOscuro,
                    ),
                    decoration: InputDecoration(
                      hintText: "Descripción de la materia y objetivos principales.",
                      hintStyle: GoogleFonts.poppins(fontSize: 15, fontWeight: FontWeight.w500, color: moradoOscuro,
                      ),
                      border: InputBorder.none,
                      isDense: true,
                    ),
                  )
                ),
              ],
            ),
          ),

          SizedBox(height: 22),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("Próximas entregas",
                style: GoogleFonts.fredoka(fontSize: 20, fontWeight: FontWeight.w700, color: moradoOscuro),
              ),
              GestureDetector(
                onTap: _vertodas,
                child: Row(
                  children: [
                    Text("Ver todas",
                      style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w600, color: morado),
                    ),
                    Icon(Icons.chevron_right, color: morado, size: 20),
                  ],
                ),
              ),
            ],
          ),

          SizedBox(height: 10),
          if (proximas.isEmpty)
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.6),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text("No tienes entregas en los próximos 7 días.",
                textAlign: TextAlign.center,
                style: GoogleFonts.poppins(fontSize: 13, color: Color(0xFF6B6BBF)),
              ),
            )
          else
            ...proximas.map((t) => Padding(
              padding: EdgeInsets.only(bottom: 12),
              child: CartaProxtareas(
                titulo: t["titulo"],
                fecha: t["fecha"],
                prioridad: t["prioridad"],
                onCheck: () => completartarea(t, widget.onCambio),
              ),
            )),

          SizedBox(height: 22),
          Material(
            color: Colors.transparent,
            child: Ink(
              height: 54,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(28),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF9675E8), Color(0xFF5B34C9)],
                ),
                boxShadow: [
                  BoxShadow(
                    color: morado.withOpacity(0.35),
                    blurRadius: 10,
                    offset: Offset(0, 5),
                  ),
                ],
              ),
              child: InkWell(
                borderRadius: BorderRadius.circular(28),
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (_) => PomodoroPage())
                  );
                },
                child: Center(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text("Iniciar Pomodoro",
                        style: GoogleFonts.poppins(fontSize: 17, fontWeight: FontWeight.w600, color: Colors.white),
                      ),

                      SizedBox(width: 8),
                      Icon(Icons.play_arrow_rounded, color: Colors.white),
                    ],
                  ),
                ),
              ),
            ),
          ),

          SizedBox(height: 16),
        ],
      ),
    );
  }
}
