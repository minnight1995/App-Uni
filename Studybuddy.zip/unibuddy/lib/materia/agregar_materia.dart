import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/utilidades/opciones_materia.dart';

class AgregarMateria extends StatefulWidget {
  final Map<String, dynamic>? materia;

  const AgregarMateria({
    super.key,
    this.materia,
  });

  @override
  State<AgregarMateria> createState() => _AgregarMateriaState();
}

class _AgregarMateriaState extends State<AgregarMateria> {
  static const morado = Color(0xFF4A2FBD);
  final materia_control = TextEditingController();
  final profesor_control = TextEditingController();
  IconData iconoelegido = Icons.school;
  Color colorelegido = Color(0xFF7C5CE6);
  bool get _editando => widget.materia != null;

  @override
  void initState() {
    super.initState();
    final m = widget.materia;
    if (m != null) {
      materia_control.text = m["nombre"];
      profesor_control.text = m["profesor"] ?? "";
      iconoelegido = listaiconos[m["icono"]];
      colorelegido = Color(m["color"]);
    }
  }

  @override
  void dispose(){
    materia_control.dispose();
    profesor_control.dispose();
    super.dispose();
  }

  void _elergiricono(){
    showModalBottomSheet(
        context: context,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
      builder: (_) => Padding(
        padding: EdgeInsets.all(24),
        child: Wrap(
          spacing: 14,
          runSpacing: 14,
          children: listaiconos.map((i){
            return GestureDetector(
              onTap: (){
                setState(() => iconoelegido = i);
                Navigator.pop(context);
              },
              child: Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: i == iconoelegido ? colorelegido : Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(i, color: i == iconoelegido ? Colors.white : Colors.black54),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  void _guardar(){
    final materia = materia_control.text.trim();

    if(materia.isEmpty){
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Escribe el nombre de la materia")),
      );
      return;
    }

    final nuevo = {
      "nombre" : materia,
      "profesor" : profesor_control.text.trim(),
      "icono" : listaiconos.indexOf(iconoelegido),
      "color" : colorelegido.value,
    };

    Navigator.pop(context, nuevo);
  }

  InputDecoration _decoration(String hint){
    return InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(color: morado.withOpacity(0.5)),
      filled: true,
      fillColor: Colors.white,
      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: morado.withOpacity(0.25)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: morado, width: 1.5),
      )

    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF3EEFF),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.black,
        title: Text(_editando ? "Guardar cambios" : "Guardar Materia",
        style: GoogleFonts.fredoka(fontSize: 22, fontWeight: FontWeight.w600, color: Color(0xFF35147D)),
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: GestureDetector(
                onTap: _elergiricono,
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Container(
                      width: 110,
                      height: 110,
                      decoration: BoxDecoration(
                        color: colorelegido.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(28),
                      ),
                      child: Icon(iconoelegido, size: 56, color: colorelegido),
                    ),

                    Positioned(
                      right: -8,
                      bottom: -8,
                      child: Container(
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: morado,
                          shape: BoxShape.circle,
                        ),
                        child: Icon(Icons.edit, color: Colors.white, size: 18),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            SizedBox(height: 28),
            Text("Nombre de la materia",
              style: GoogleFonts.fredoka(fontSize: 18, fontWeight: FontWeight.w700,color: Color(0xFF35147D)),
            ),

            SizedBox(height: 8),
            TextField(
                controller: materia_control,
                decoration: _decoration("Ej: Desarrollo de aplicaciones"),
            ),

            SizedBox(height: 20),
            Text("Profesor (opcional)",
              style: GoogleFonts.fredoka(fontSize: 18, fontWeight: FontWeight.w700,color: Color(0xFF35147D)),
            ),

            SizedBox(height: 8),
            TextField(
              controller: profesor_control,
              decoration: _decoration("Ej: Prof. Jhon Dimas"),
            ),

            SizedBox(height: 20),
            Text("Color de la materia",
              style: GoogleFonts.fredoka(fontSize: 18, fontWeight: FontWeight.w700,color: Color(0xFF35147D)),
            ),

            SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: listacolores.map((c) {
                final elegido = c == colorelegido;
                return GestureDetector(
                  onTap: () => setState(() => colorelegido = c),
                  child: Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: c,
                      shape: BoxShape.circle,
                      border: elegido
                        ?Border.all(color: morado, width: 3)
                          :null,
                    ),
                  ),
                );
              }).toList(),
            ),

            SizedBox(height: 36),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                  onPressed: _guardar,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: morado,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(26),
                    ),
                  ),
                  child: Text(_editando ? "Guardar cambios" : "Guardar Materia",
                    style: GoogleFonts.poppins(fontSize: 18,fontWeight: FontWeight.w600, color: Colors.white),
                  ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
