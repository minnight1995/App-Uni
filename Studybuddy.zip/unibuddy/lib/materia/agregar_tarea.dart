import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/utilidades//materias.dart';

class AgregarTarea extends StatefulWidget {
  const AgregarTarea({super.key});

  @override
  State<AgregarTarea> createState() => _AgregarTareaState();
}

class _AgregarTareaState extends State<AgregarTarea> {
  static const morado = Color(0xFF4A2FBD);
  static const moradoOscuro = Color(0xFF35147D);
  final titulo_control = TextEditingController();
  DateTime _dia = DateTime.now();
  TimeOfDay _hora = TimeOfDay(hour: 23, minute: 59);
  String _prioridad = 'Media';

  @override
  void dispose() {
    titulo_control.dispose();
    super.dispose();
  }

  Future<void> _elegirdia() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _dia,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );

    if (d != null) setState(() => _dia = d);
  }

  Future<void> _elegirhora() async {
    final h = await showTimePicker(context: context, initialTime: _hora);
    if (h != null) setState(() => _hora = h);
  }

  void _guardar() {
    final titulo = titulo_control.text.trim();
    if (titulo.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Escribe el título de la tarea")),
      );
      return;
    }
    final fecha = DateTime(_dia.year, _dia.month, _dia.day, _hora.hour, _hora.minute);
    Navigator.pop(context, {
      "titulo": titulo,
      "fecha": fecha,
      "prioridad": _prioridad,
    });
  }

  Widget _selector(IconData icono, String texto, VoidCallback onTap) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: morado.withOpacity(0.25)),
          ),
          child: Row(
            children: [
              Icon(icono, color: morado, size: 20),

              SizedBox(width: 10),
              Text(texto,
                  style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w500, color: moradoOscuro)
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF3EEFF),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        foregroundColor: moradoOscuro,
        title: Text("Nueva Tarea",
            style: GoogleFonts.fredoka(fontSize: 22, fontWeight: FontWeight.w600, color: moradoOscuro)
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Título",
                style: GoogleFonts.fredoka(fontSize: 18, fontWeight: FontWeight.w700, color: moradoOscuro),
            ),

            SizedBox(height: 8),
            TextField(
              controller: titulo_control,
              decoration: InputDecoration(
                hintText: "Ej: Entregar proyecto final",
                hintStyle: TextStyle(color: morado.withOpacity(0.5)),
                filled: true,
                fillColor: Colors.white,
                contentPadding:
                EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide(color: morado.withOpacity(0.25)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide(color: morado, width: 1.5),
                ),
              ),
            ),

            SizedBox(height: 20),
            Text("Fecha y hora de entrega",
              style: GoogleFonts.fredoka(fontSize: 18, fontWeight: FontWeight.w700, color: moradoOscuro),
            ),

            SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: _selector(
                      Icons.calendar_today_outlined, 
                      '${_dia.day}/${_dia.month}/${_dia.year}', 
                      _elegirdia,
                  ),
                ),
                
                SizedBox(height: 12),
                Expanded(
                  child: _selector(Icons.access_time_rounded, _hora.format(context), _elegirhora),
                ),
              ],
            ),

            SizedBox(height: 20),
            Text("Prioridad",
              style: GoogleFonts.fredoka(fontSize: 18, fontWeight: FontWeight.w700, color: moradoOscuro),
            ),

            SizedBox(height: 8),
            Row(
              children: ["Alta", "Media", "Baja"].map((p){
                final activa = p == _prioridad;
                final c = colorprioridad(p);
                return Expanded(
                    child: GestureDetector(
                        onTap: () => setState(() => _prioridad = p),
                        child: AnimatedContainer(
                            duration: Duration(milliseconds: 200),
                            margin: EdgeInsets.symmetric(horizontal: 4),
                            padding: EdgeInsets.symmetric(vertical: 12),
                            decoration: BoxDecoration(
                              color: activa ? c.withOpacity(0.2) : Colors.white,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(
                                color: activa ? c : morado.withOpacity(0.25),
                                width: activa ? 2 : 1,
                              ),
                            ),
                          child: Text(p,
                            textAlign: TextAlign.center,
                            style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w600, color: moradoOscuro),
                          ),
                          ),
                    )
                );
              }).toList()
            ),

            SizedBox(height: 36),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _guardar,
                style: ElevatedButton.styleFrom(
                  backgroundColor: morado,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(26)),
                ),
                child: Text("Guardar Tarea",
                    style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w600)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
