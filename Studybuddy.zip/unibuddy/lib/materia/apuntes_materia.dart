import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/cartas/carta_apunte.dart';
import 'package:unibuddy/pages/apunte_page.dart';
import 'package:unibuddy/utilidades/apuntes.dart';
import 'package:unibuddy/utilidades/materias.dart';
import 'package:unibuddy/api.dart';

class ApuntesMateria extends StatelessWidget {
  final List<Map<String, dynamic>> apuntes;
  final VoidCallback onCambio;
  final int materiaId;


  const ApuntesMateria({
    super.key,
    required this.materiaId,
    required this.apuntes,
    required this.onCambio,
  });

  static const moradoOscuro = Color(0xFF35147D);

  Future<void> _abrir(BuildContext context, {Map<String, dynamic>? apunte}) async {
    final r = await Navigator.push<Map<String, dynamic>>(
      context, MaterialPageRoute(builder: (_) => ApuntePage(apunte: apunte)),
    );
    if (r == null) return;

    final token = await leerToken();
    if (token == null) return;

    Map<String, dynamic> res;

    if (r["accion"] == "borrar") {
      res = await borrarApunte(token, apunte!["id"]);
      if (!res.containsKey("error")) apuntes.remove(apunte);
    } else if (apunte == null) {
      res = await crearApunte(
        token: token,
        materiaId: materiaId,
        titulo: r["titulo"],
        contenido: r["contenido"],
        fecha: DateTime.now(),
      );
      if (!res.containsKey("error")) apuntes.add(res);
    } else {
      final ahora = DateTime.now();
      res = await actualizarApunte(
          token, apunte["id"], r["titulo"], r["contenido"], ahora);
      if (!res.containsKey("error")) {
        apunte["titulo"] = r["titulo"];
        apunte["contenido"] = r["contenido"];
        apunte["fecha"] = ahora;
      }
    }
    if (res.containsKey('error') && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(res["error"])),
    );
    }
    onCambio();
  }

  @override
  Widget build(BuildContext context) {
    final ordenados = [...apuntes]..sort((a, b) =>
        (b["fecha"] as DateTime).compareTo(a["fecha"] as DateTime));

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomPaint(
            foregroundPainter: _BordeDiscontinuo(const Color(0xFFE8A317)),
            child: Material(
              color: Color(0xFFFFF3DC),
              borderRadius: BorderRadius.circular(20),
              child: InkWell(
                borderRadius: BorderRadius.circular(20),
                onTap: () => _abrir(context),
                child: Padding(
                    padding: EdgeInsets.symmetric(vertical: 22),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.add_rounded, color: Color(0xFFE8A317), size: 32),

                      SizedBox(width: 10),
                      Text("Agregar apunte",
                        style: GoogleFonts.fredoka(fontSize: 18, fontWeight: FontWeight.w600, color: moradoOscuro),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          SizedBox(height: 20),
          Text("Mis apuntes",
            style: GoogleFonts.fredoka(fontSize: 20, fontWeight: FontWeight.w700, color: moradoOscuro),
          ),

          SizedBox(height: 5),
          if (ordenados.isEmpty)
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.6),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text("Aún no tienes apuntes en esta materia.",
                textAlign: TextAlign.center,
                style: GoogleFonts.poppins(fontSize: 13, color: Color(0xFF6B6BBF)),
              ),
            )
          else
            GridView.builder(
              padding: EdgeInsets.zero,
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: ordenados.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.05,
              ),
              itemBuilder: (context, i) {
                final a = ordenados[i];
                final colores = paletaapuntes[(a["id"] as int) % paletaapuntes.length];

                return CartaApunte(
                  titulo: a["titulo"],
                  fecha: fechacorta(a["fecha"]),
                  fondo: colores[0],
                  acento: colores[1],
                  onTap: () => _abrir(context, apunte: a),
                );
              },
            ),
          SizedBox(height: 16),
        ],
      ),
    );
  }
}
class _BordeDiscontinuo extends CustomPainter {
  final Color color;
  _BordeDiscontinuo(this.color);

  @override
  void paint(Canvas canvas, Size size) {
    const grosor = 2.0;
    final pincel = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = grosor;
    final rect = Rect.fromLTWH(
        grosor / 2,
        grosor / 2,
        size.width - grosor,
        size.height - grosor
    );
    final ruta = Path()
      ..addRRect(RRect.fromRectAndRadius(rect, const Radius.circular(19)));
    for (final metrica in ruta.computeMetrics()) {
      double d = 0;
      while (d < metrica.length) {
        canvas.drawPath(metrica.extractPath(d, d + 8), pincel);
        d += 14;
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
