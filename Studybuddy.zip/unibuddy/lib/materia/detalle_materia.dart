import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/barras/barra_navegacion.dart';
import 'package:unibuddy/materia/agregar_materia.dart';
import 'package:unibuddy/materia/apuntes_materia.dart';
import 'package:unibuddy/materia/resumen_materia.dart';
import 'package:unibuddy/materia/tareas_materia.dart';
import 'package:unibuddy/utilidades/opciones_materia.dart';
import 'package:unibuddy/widgets/widget_materia.dart';
import 'package:unibuddy/api.dart';


class DetalleMateria extends StatefulWidget {
  final Map<String, dynamic> materia;

  const DetalleMateria({
    super.key,
    required this.materia
  });

  @override
  State<DetalleMateria> createState() => _DetalleMateriaState();
}

class _DetalleMateriaState extends State<DetalleMateria> {
  static const morado = Color(0xFF4A2FBD);
  static const moradoOscuro = Color(0xFF35147D);
  int _seccion = 0;
  final descripcion_control = TextEditingController();
  final List<Map<String, dynamic>> tareas = [];
  final List<Map<String, dynamic>> apuntes = [];



  void dispose(){
    super.dispose();
    descripcion_control.dispose();
  }
  @override
  void initState() {
    super.initState();
    _cargartareas();
    _cargarapuntes();
  }

  Future<void> _cargartareas() async {
    final token = await leerToken();
    if (token == null) return;

    final lista = await listarTareas(token, widget.materia["id"]);
    if (!mounted || lista == null) return;
    setState(() {
      tareas
        ..clear()
        ..addAll(lista);
      _actualizarprogreso();
    });
  }

  void _actualizarprogreso() {
    if (tareas.isEmpty) {
      widget.materia["progreso"] = 0.0;
      return;
    }
    final hechas = tareas.where((t) => t["completada"] == true).length;
    widget.materia["progreso"] = hechas / tareas.length;
  }

  void _refrescar() {
    if (!mounted) return;
    setState(() => _actualizarprogreso());
  }

  Future<void> _editarmateria() async {
    final cambios = await Navigator.push<Map<String, dynamic>>(
      context,
      MaterialPageRoute(builder: (_) => AgregarMateria(materia: widget.materia),
      ),
    );
    if (cambios == null) return;

    final m = widget.materia;
    final sinCambios = cambios["nombre"] == m["nombre"] &&
        cambios["profesor"] == (m["profesor"] ?? "") &&
        cambios["icono"] == m["icono"] &&
        cambios["color"] == m["color"];
    if (sinCambios) return;

    final token = await leerToken();
    if (token == null) return;

    final r = await actualizarMateria(
      token,
      m["id"],
      cambios["nombre"],
      cambios["profesor"],
      cambios["icono"],
      cambios["color"],
    );
    if (!mounted) return;

    if (r.containsKey("error")) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(r["error"])),
      );
      return;
    }

    setState(() {
      m["nombre"] = cambios["nombre"];
      m["profesor"] = cambios["profesor"];
      m["icono"] = cambios["icono"];
      m["color"] = cambios["color"];
    });
  }
  Future<void> _cargarapuntes() async {
    final token = await leerToken();
    if (token == null) return;

    final lista = await listarApuntes(token, widget.materia["id"]);
    if (!mounted || lista == null) return;
    setState(() {
      apuntes
        ..clear()
        ..addAll(lista);
    });
  }

  @override
  Widget build(BuildContext context) {
    final m = widget.materia;
    final color = Color(m["color"]);
    final icono = listaiconos[m["icono"]];
    final profesor = (m["profesor"] == null || m["profesor"] == '')
        ? "Sin profesor"
        : m["profesor"];
    final arriba = MediaQuery.of(context).padding.top + kToolbarHeight;

    return Scaffold(
      backgroundColor: Color(0xFFF5EFFB),
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        foregroundColor: Colors.white,
        leading: IconButton(icon: Icon(Icons.arrow_back), onPressed: () => Navigator.pop(context)),
        actions: [IconButton(icon: Icon(Icons.edit_outlined), onPressed: _editarmateria)],
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: EdgeInsets.fromLTRB(16, arriba, 16, 28),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [color, Color.lerp(color, moradoOscuro, 0.55)!],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(32)),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Positioned(
                  left: 24,
                  top: 4,
                  child: Icon(Icons.auto_awesome, color: Colors.white.withOpacity(0.35), size: 22),
                ),

                Positioned(
                    right:28,
                    top: 60,
                  child: Icon(Icons.auto_awesome, color: Colors.white.withOpacity(0.35), size: 18),
                ),

                Column(
                  children: [
                    Container(
                      width: 84,
                      height: 84,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.25),
                        borderRadius: BorderRadius.circular(26),
                      ),
                      child: Icon(icono, color: Colors.white, size: 46),
                    ),

                    SizedBox(height: 14),
                    Text(m["nombre"],
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.fredoka(fontSize: 26, fontWeight: FontWeight.w700, color: Colors.white),
                    ),

                    SizedBox(height: 2),
                    Text(profesor,
                      style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w500, color: Colors.white.withOpacity(0.9)),
                    ),
                  ],
                ),
              ],
            ),
          ),

          Expanded(
            child: Padding(
              padding: EdgeInsetsGeometry.fromLTRB(20, 16, 20, 0),
              child: Column(
                children: [
                  WidgetMateria(
                    opciones: ["Resumen", "Tareas", "Apuntes"],
                    indice: _seccion,
                    onCambio: (i) => setState(() => _seccion = i),
                  ),

                  SizedBox(height: 16),
                  Expanded(child: _contenido())
                ],
              ),
            )
          ),
        ],
      ),
      bottomNavigationBar: BarraNavegacion(indice: 1),
    );
  }

  Widget _contenido() {
    switch (_seccion) {
      case 1:
        return TareasMateria(
          materiaId: widget.materia['id'],
          tareas: tareas,
          onCambio: _refrescar,
        );
      case 2:
        return  ApuntesMateria(
          materiaId: widget.materia["id"],
            apuntes: apuntes,
            onCambio: () {
              if (mounted) setState(() {});
            },)
        ; // tu widget de apuntes
      default:
        return ResumenMateria(
          materia: widget.materia,
          tareas: tareas,
          onCambio:_refrescar,
        );
    }
  }

}
