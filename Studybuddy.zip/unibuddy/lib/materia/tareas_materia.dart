import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/cartas/carta_proxtareas.dart';
import 'package:unibuddy/pages/tareas_page.dart';
import 'package:unibuddy/utilidades/materias.dart';

class TareasMateria extends StatelessWidget {
  final List<Map<String, dynamic>> tareas;
  final VoidCallback onCambio;
  final int materiaId;


  const TareasMateria({
    super.key,
    required this.materiaId,
    required this.tareas,
    required this.onCambio,
  });

  Future<void> _vertodas(BuildContext context) async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => TareasPage(tareas: tareas, materiaId: materiaId)),
    );
    onCambio(); 
  }
  @override
  Widget build(BuildContext context) {
    const morado = Color(0xFF4A2FBD);
    final pendientes = tareas.where((t) => t["completada"] != true).toList()
      ..sort((a, b) =>
          (a["fecha"] as DateTime).compareTo(b["fecha"] as DateTime));
    final visibles = pendientes.take(3).toList();

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("Tareas pendientes",
                style: GoogleFonts.fredoka(fontSize: 20, fontWeight: FontWeight.w700, color: Color(0xFF35147D)),
              ),
              GestureDetector(
                onTap: () => _vertodas(context),
                child: Row(
                  children: [
                    Text("Ver todas",
                      style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w600, color: morado,
                      ),
                    ),

                    Icon(Icons.chevron_right, color: morado, size: 20),
                  ],
                ),
              )
            ],
          ),

          SizedBox(height: 10),
          if (visibles.isEmpty)
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.6),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text("No tienes tareas pendientes.",
                textAlign: TextAlign.center,
                style: GoogleFonts.poppins(fontSize: 13, color: Color(0xFF6B6BBF),
                ),
              ),
            )
          else
            ...visibles.map((t) => Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: CartaProxtareas(
                titulo: t["titulo"],
                subtitulo: formatearfecha(t["fecha"]),
                color: colorprioridad(t["prioridad"]),
                prioridad: t["prioridad"],
                onCheck: () => completartarea(t, onCambio)
              ),
            )),

          SizedBox(height: 16),
        ],
      ),
    );
  }
}
