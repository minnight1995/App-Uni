import 'package:flutter/material.dart';
import 'package:unibuddy/onboarding/bienvenida_page.dart';

void main() {
  runApp(const UniBuddy());
}

class UniBuddy extends StatelessWidget {
  const UniBuddy({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'UniBuddy',
      home: BienvenidaPage(),
    );
  }
}
