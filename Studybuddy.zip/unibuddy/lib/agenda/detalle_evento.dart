import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/utilidades/agenda.dart';
import 'package:unibuddy/utilidades/eventos.dart';

class DetalleEvento extends StatelessWidget {
  final ItemAgenda item;

  const DetalleEvento({
    super.key,
    required this.item,
  });

  static const _morado = Color(0xFF4A2FBD);
  static const _oscuro = Color(0xFF35147D);

  Future<void> _confirmarBorrar(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("Eliminar evento"),
        content: Text('¿Seguro que quieres eliminar "${item.titulo}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('Cancelar'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text('Eliminar',
                style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    if (ok == true && context.mounted) Navigator.pop(context, "eliminar");
  }

  Widget _dato(IconData icono, String texto) => Padding(
    padding: EdgeInsets.only(bottom: 14),
    child: Row(
      children: [
        Icon(icono, color: _morado, size: 24),

        SizedBox(width: 14),
        Expanded(
          child: Text(
            texto,
            style: GoogleFonts.poppins(fontSize: 15, fontWeight: FontWeight.w500, color: _oscuro,
            ),
          ),
        ),
      ],
    ),
  );
  
  @override
  Widget build(BuildContext context) {
    final cat = categoriasagenda[item.categoria];

    return Scaffold(
      backgroundColor: Color(0xFFF3EEFF),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        foregroundColor: _oscuro,
        title: Text("Detalle del evento",
          style: GoogleFonts.fredoka(fontSize: 22, fontWeight: FontWeight.w600, color: _oscuro,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(20, 4, 20, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              height: 130,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                gradient: LinearGradient(
                  colors: [
                    item.color.withOpacity(0.35),
                    item.color.withOpacity(0.12),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Icon(cat.icono, size: 64, color: item.color),
            ),

            SizedBox(height: 18),
            Text(item.titulo,
              style: GoogleFonts.fredoka(fontSize: 26, fontWeight: FontWeight.w700, color: _oscuro,
              ),
            ),

            SizedBox(height: 8),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: item.color.withOpacity(0.2),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Text(cat.nombre,
                style: GoogleFonts.poppins(fontSize: 13, fontWeight: FontWeight.w600, color: _oscuro),
              ),
            ),

            SizedBox(height: 20),

            _dato(Icons.calendar_month_rounded, fechalarga(item.inicio)),
            _dato(Icons.access_time_rounded, item.horario),
            if (item.lugar.isNotEmpty)
              _dato(Icons.location_on_rounded, item.lugar),

            if(item.descripcion.isNotEmpty) ...[
              SizedBox(height: 6),
              Text("Descripción",
                style: GoogleFonts.fredoka(fontSize: 17, fontWeight: FontWeight.w700, color: _oscuro,
                ),
              ),

              SizedBox(height: 6),
              Text(item.descripcion,
                style: GoogleFonts.poppins(fontSize: 14, color: _oscuro.withOpacity(0.85),
                ),
              ),
            ],
            SizedBox(height: 28),
            if(item.esclase)
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Row(
                  children: [
                    Icon(Icons.info_outline_rounded, color: _morado),

                    SizedBox(width: 12),
                    Expanded(
                      child: Text("Esta clase se edita en Horario",
                        style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w600, color: _oscuro),
                      ),
                    ),
                  ],
                ),
              )
            else ...[
              SizedBox(
                width: double.infinity,
                height: 52,
                child: OutlinedButton.icon(
                  onPressed: () => Navigator.pop(context, "editar"),
                  icon: Icon(Icons.edit_rounded),
                  label: Text("Editar evento",
                      style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w600)
                  ),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: _morado,
                    side: BorderSide(color: _morado, width: 1.5),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(26)
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: OutlinedButton.icon(
                  onPressed: () => _confirmarBorrar(context),
                  icon: Icon(Icons.delete_rounded),
                  label: Text("Eliminar evento",
                      style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w600)),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.red,
                    side: BorderSide(color: Colors.red, width: 1.5),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(26)),
                  ),
                ),
              ),
            ]
          ],
        ),
      ),
    );
  }
}
