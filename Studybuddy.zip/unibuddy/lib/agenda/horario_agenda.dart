import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/barras/barra_dias.dart';
import 'package:unibuddy/cartas/carta_clase.dart';
import 'package:unibuddy/utilidades/agenda.dart';

class HorarioAgenda extends StatefulWidget {
  final List<Map<String, dynamic>> materias;
  final List<Map<String, dynamic>> clases;
  final VoidCallback onAgregar;
  final ValueChanged<Map<String, dynamic>> onOpciones;

  const HorarioAgenda({
    super.key,
    required this.materias,
    required this.clases,
    required this.onAgregar,
    required this.onOpciones,

  });

  @override
  State<HorarioAgenda> createState() => _HorarioAgendaState();
}

class _HorarioAgendaState extends State<HorarioAgenda> {
  static const morado = Color(0xFF4A2FBD);
  static const moradoOscuro = Color(0xFF35147D);
  late int _dia;

  @override
  void initState() {
    super.initState();
    _dia = DateTime.now().weekday;
  }

  Map<String, dynamic>? _materia(int id) {
    for (final m in widget.materias) {
      if (m["id"] == id) return m;
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final hoy = DateTime.now();
    final deldia = widget.clases.where((c) => c["dia"] == _dia).toList()
      ..sort((a, b) =>
          (a["inicio"] as String).compareTo(b["inicio"] as String));
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
            child: Padding(
                padding: EdgeInsetsGeometry.fromLTRB(24, 4, 14, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Horario",
                    style: GoogleFonts.fredoka(fontSize: 24, fontWeight: FontWeight.w700, color: moradoOscuro),
                  ),

                  SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    height: 44,
                    child: ElevatedButton.icon(
                      onPressed: widget.onAgregar,
                      icon: Icon(Icons.add_rounded, size: 20),
                      label: Text("Agregar horario",
                        style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w600),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: morado,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(22),
                        ),
                      ),
                    ),
                  ),
                  
                  SizedBox(height: 14),
                  Expanded(
                      child: deldia.isEmpty
                          ?Center(
                        child: Text("No tienes clases el ${nombresdias[_dia - 1].toLowerCase()}. Toca 'Agregar horario' para registrar una.",
                        textAlign: TextAlign.center,
                          style: GoogleFonts.poppins(
                            fontSize: 13,
                            color: Color(0xFF6B6BBF)),
                        ),
                      )
                          :ListView.separated(
                        padding: EdgeInsets.only(bottom: 16),
                        separatorBuilder: (_, __) => SizedBox(height: 12),
                        itemCount: deldia.length,
                        itemBuilder: (context, i){
                          final c = deldia[i];
                          final m = _materia(c["materia_id"]);
                          if (m == null) return const SizedBox.shrink();

                          return CartaClase(
                            nombre: m["nombre"],
                            profesor: (m["profesor"] ?? "").toString(),
                            color: Color(m["color"]),
                            salon: (c["salon"] ?? "").toString(),
                            inicio: c["inicio"],
                            fin: c["fin"],
                            onLongPress: () => widget.onOpciones(c),
                          );
                        },
                      ),
                  ),
                ],
              ),
            ),
        ),

        BarraDias(
          hoy: hoy,
          seleccionado: _dia,
          onDia: (d) => setState(() => _dia = d),
        ),
      ],
    );
  }
}
