import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/utilidades/agenda.dart';

class AgregarClase extends StatefulWidget {
  final List<Map<String, dynamic>> materias;
  final Map<String, dynamic>? clase;

  const AgregarClase({
    super.key,
    required this.materias,
    this.clase,
  });

  @override
  State<AgregarClase> createState() => _AgregarClaseState();
}

class _AgregarClaseState extends State<AgregarClase> {
  static const morado = Color(0xFF4A2FBD);
  static const moradoOscuro = Color(0xFF35147D);
  int? _materiaId;
  final Set<int> _dias = {};
  TimeOfDay _inicio = const TimeOfDay(hour: 7, minute: 0);
  TimeOfDay _fin = const TimeOfDay(hour: 9, minute: 0);
  final _saloncontrol = TextEditingController();
  bool get _editando => widget.clase != null;
  TimeOfDay _aHora(String s) {
    final p = s.split(':');
    return TimeOfDay(hour: int.parse(p[0]), minute: int.parse(p[1]));
  }

  @override
  void initState() {
    super.initState();
    final c = widget.clase;
    if (c != null) {
      _materiaId = c["materia_id"];
      _dias.add(c["dia"]);
      _inicio = _aHora(c["inicio"]);
      _fin = _aHora(c["fin"]);
      _saloncontrol.text = (c["salon"] ?? "").toString();
    }
  }
  @override
  void dispose() {
    _saloncontrol.dispose();
    super.dispose();
  }


  Future<void> _elegirhora(bool esinicio) async {
    final h = await showTimePicker(
      context: context,
      initialTime: esinicio ? _inicio : _fin,
    );
    if (h == null) return;
    setState(() => esinicio ? _inicio = h : _fin = h);
  }

  void _aviso(String texto) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(texto)),
    );
  }

  void _guardar() {
    if (_materiaId == null) return _aviso("Elige la materia");
    if (_dias.isEmpty) return _aviso("Elige al menos un día");

    final ini = _inicio.hour * 60 + _inicio.minute;
    final fin = _fin.hour * 60 + _fin.minute;
    if (fin <= ini) {
      return _aviso("La hora de fin debe ser después de la de inicio");
    }

    final dias = _dias.toList()..sort();
    final base = DateTime.now().millisecondsSinceEpoch;
    final nuevas = <Map<String, dynamic>>[];
    for (var i = 0; i < dias.length; i++) {
      if (_editando) {
        Navigator.pop(context, {
          "materia_id": _materiaId,
          "dia": dias.first,
          "inicio": horatexto(_inicio),
          "fin": horatexto(_fin),
          "salon": _saloncontrol.text.trim(),
        });
        return;
      }
    }
    Navigator.pop(context, {
      "materia_id": _materiaId,
      "dias": (_dias.toList()..sort()),
      "inicio": horatexto(_inicio),
      "fin": horatexto(_fin),
      "salon": _saloncontrol.text.trim(),
    });
  }

  Widget _caja({required Widget hijo, VoidCallback? onTap}) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: morado.withOpacity(0.25)),
          ),
          child: hijo,
        ),
      ),
    );
  }

  Widget _tiempo(String titulo, TimeOfDay hora, bool esinicio) {
    return Expanded(
      child: _caja(
        onTap: () => _elegirhora(esinicio),
        hijo: Row(
          children: [
            Icon(Icons.access_time_rounded, color: morado, size: 20),

            SizedBox(width: 8),
            Expanded(
              child: Text(
                "$titulo  ${hora.format(context)}",
                style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w500, color: moradoOscuro,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF3EEFF),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        foregroundColor: moradoOscuro,
        title: Text(_editando ? "Editar horario" : "Agregar horario",
          style: GoogleFonts.fredoka(fontSize: 22, fontWeight: FontWeight.w600, color: moradoOscuro,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Materia",
              style: GoogleFonts.fredoka(fontSize: 18, fontWeight: FontWeight.w700, color: moradoOscuro),
            ),

            SizedBox(height: 8),
            _caja(
                hijo: DropdownButtonHideUnderline(
                    child: DropdownButton<int>(
                        isExpanded: true,
                        value: _materiaId,
                        hint: Text('Elige una materia',
                          style: GoogleFonts.poppins(fontSize: 14, color: morado.withOpacity(0.5)),
                        ),
                      items: widget.materias.map((m){
                        return DropdownMenuItem<int>(
                          value: m["id"],
                          child: Row(
                            children: [
                              Container(
                                width: 12,
                                height: 12,
                                decoration: BoxDecoration(
                                  color: Color(m['color']),
                                  shape: BoxShape.circle,
                                ),
                              ),

                              SizedBox(width: 10),
                              Expanded(
                                  child: Text(m["nombre"],
                                    overflow: TextOverflow.ellipsis,
                                    style: GoogleFonts.poppins(fontSize: 14, color: moradoOscuro),
                                  ),
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                      onChanged: (v) => setState(() => _materiaId = v),
                    ),
                ),
            ),

            SizedBox(height: 20),
            Text("Días",
              style: GoogleFonts.fredoka(fontSize: 18, fontWeight: FontWeight.w700, color: moradoOscuro),
            ),

            SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: List.generate(7, (i){
                final dia = i + 1;
                final activo = _dias.contains(dia);
                return GestureDetector(
                    onTap: () => setState(() {
                      if (_editando) {
                        _dias
                          ..clear()
                          ..add(dia);
                      } else {
                        activo ? _dias.remove(dia) : _dias.add(dia);
                      }
                    }),
                    child: AnimatedContainer(
                        duration: Duration(milliseconds: 200),
                      padding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        color: activo ? morado : Colors.white,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: activo ? morado : morado.withOpacity(0.25),
                        ),
                      ),
                      child: Text(diascortos[i],
                        style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w600,
                          color: activo ? Colors.white : moradoOscuro),
                      ),
                    ),
                );
              }),
            ),

            SizedBox(height: 20),
            Text("Hora",
              style: GoogleFonts.fredoka(fontSize: 18, fontWeight: FontWeight.w700, color: moradoOscuro),
            ),

            SizedBox(height: 8),
            Row(
              children: [
                _tiempo("Inicio", _inicio, true),

                SizedBox(width: 12),
                _tiempo("Fin", _fin, false),
              ],
            ),

            SizedBox(height: 20),
            Text("Salón (opcional)",
              style: GoogleFonts.fredoka(fontSize: 18, fontWeight: FontWeight.w700, color: moradoOscuro),
            ),

            SizedBox(height: 8),
            TextField(
              controller: _saloncontrol,
              decoration: InputDecoration(
                hintText: 'Ej: ML203',
                hintStyle: TextStyle(color: morado.withOpacity(0.5)),
                filled: true,
                fillColor: Colors.white,
                contentPadding:
                EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide(color: morado.withOpacity(0.25)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide(color: morado, width: 1.5),
                ),
              ),
            ),

            SizedBox(height: 36),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _guardar,
                style: ElevatedButton.styleFrom(
                  backgroundColor: morado,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(26),
                  ),
                ),
                child: Text(_editando ? "Guardar cambios" : "Guardar horario",
                  style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w600),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
