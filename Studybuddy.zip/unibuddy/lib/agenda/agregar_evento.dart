import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/utilidades/agenda.dart';
import 'package:unibuddy/utilidades/eventos.dart';

class AgregarEvento extends StatefulWidget {
  final Map<String, dynamic>? evento;
  final DateTime? fechaInicial;

  const AgregarEvento({
    super.key,
    this.evento,
    this.fechaInicial,
  });

  @override
  State<AgregarEvento> createState() => _AgregarEventoState();
}

class _AgregarEventoState extends State<AgregarEvento> {
  static const morado = Color(0xFF4A2FBD);
  static const moradoOscuro = Color(0xFF35147D);
  final _titulocontrol = TextEditingController();
  final _lugarcontrol = TextEditingController();
  final _descripcioncontrol = TextEditingController();
  DateTime? _dia;
  TimeOfDay? _hora;
  TimeOfDay? _fin;
  int _categoria = 0;
  bool get _editando => widget.evento != null;

  @override
  void initState() {
    super.initState();
    final e = widget.evento;
    if (e != null) {
      _titulocontrol.text = e["titulo"];
      _lugarcontrol.text = (e["lugar"] ?? "").toString();
      _descripcioncontrol.text = (e["descripcion"] ?? "").toString();
      _categoria = (e["categoria"] is int &&
          e["categoria"] < categoriasagenda.length)
          ? e["categoria"]
          : categoriasagenda.length - 1;

      final ini = e["inicio"] as DateTime;
      _dia = DateTime(ini.year, ini.month, ini.day);
      _hora = TimeOfDay(hour: ini.hour, minute: ini.minute);
      final fin = e["fin"] as DateTime?;
      if (fin != null) _fin = TimeOfDay(hour: fin.hour, minute: fin.minute);
    } else if (widget.fechaInicial != null) {
      final f = widget.fechaInicial!;
      _dia = DateTime(f.year, f.month, f.day);
    }
  }

  @override
  void dispose() {
    _titulocontrol.dispose();
    _lugarcontrol.dispose();
    _descripcioncontrol.dispose();
    super.dispose();
  }

  String _textohora(TimeOfDay t) =>
      horaampm(DateTime(2000, 1, 1, t.hour, t.minute));

  Future<void> _elegirdia() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _dia ?? DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (d != null) setState(() => _dia = d);
  }

  Future<void> _elegirhora() async {
    final h = await showTimePicker(
      context: context,
      initialTime: _hora ?? const TimeOfDay(hour: 8, minute: 0),
    );
    if (h != null) setState(() => _hora = h);
  }

  Future<void> _elegirfin() async {
    final base = _hora ?? const TimeOfDay(hour: 8, minute: 0);
    final h = await showTimePicker(
      context: context,
      initialTime: _fin ??
          TimeOfDay(hour: (base.hour + 1) % 24, minute: base.minute),
    );
    if (h != null) setState(() => _fin = h);
  }

  void _aviso(String texto) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(texto)),
    );
  }

  void _guardar() {
    final titulo = _titulocontrol.text.trim();
    if (titulo.isEmpty) return _aviso('Escribe el título del evento');
    if (_dia == null) return _aviso('Elige la fecha');
    if (_hora == null) return _aviso('Elige la hora');

    final inicio = DateTime(
        _dia!.year, _dia!.month, _dia!.day, _hora!.hour, _hora!.minute);

    DateTime? fin;
    if (_fin != null) {
      fin = DateTime(
          _dia!.year, _dia!.month, _dia!.day, _fin!.hour, _fin!.minute);
      if (!fin.isAfter(inicio)) {
        return _aviso('La hora de fin debe ser después de la de inicio');
      }
    }

    Navigator.pop(context, {
      "titulo": titulo,
      "categoria": _categoria,
      "inicio": inicio,
      "fin": fin,
      "lugar": _lugarcontrol.text.trim(),
      "descripcion": _descripcioncontrol.text.trim(),
    });
  }

  Widget _icono(IconData icono) => Container(
    width: 44,
    height: 44,
    decoration: BoxDecoration(
      color: Color(0xFFE4D9F7),
      borderRadius: BorderRadius.circular(14),
    ),
    child: Icon(icono, color: morado, size: 22),
  );

  InputDecoration _campo(String hint) => InputDecoration(
    hintText: hint,
    hintStyle: GoogleFonts.poppins(
        fontSize: 14, color: morado.withOpacity(0.5)),
    filled: true,
    fillColor: Color(0xFFF1EBFC),
    isDense: true,
    contentPadding:
    EdgeInsets.symmetric(horizontal: 14, vertical: 12),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: BorderSide.none,
    ),
  );

  Widget _seleccion({
    required IconData icono,
    required String titulo,
    required String? valor,
    required String hint,
    required VoidCallback onTap,
    VoidCallback? onLimpiar,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: onTap,
          child: Padding(
            padding: EdgeInsets.all(14),
            child: Row(
              children: [
                _icono(icono),

                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(titulo, style: GoogleFonts.fredoka(fontSize: 17, fontWeight: FontWeight.w700,
                        color: moradoOscuro)
                      ),
                      Text(valor ?? hint,
                        style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w500,
                          color: valor == null ? morado.withOpacity(0.6) : moradoOscuro),
                      ),
                    ],
                  ),
                ),
                if (onLimpiar != null && valor != null)
                  IconButton(
                    icon: const Icon(Icons.close_rounded, color: morado),
                    onPressed: onLimpiar,
                  )
                else
                  const Icon(Icons.chevron_right, color: morado),
              ],
            ),
          ),
        ),
      ),
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF3EEFF),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        foregroundColor: moradoOscuro,
        title: Text(_editando ? "Editar evento" : "Nuevo evento",
          style: GoogleFonts.fredoka(fontSize: 22, fontWeight: FontWeight.w600, color: moradoOscuro,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(20, 4, 20, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _icono(Icons.edit_calendar_rounded),

                  SizedBox(width: 12),
                  Expanded(
                      child: Column(
                        children: [
                          Text("Título del evento",
                            style: GoogleFonts.fredoka(fontSize: 17, fontWeight: FontWeight.w700, color: moradoOscuro),
                          ),

                          SizedBox(height: 6),
                          TextField(
                            controller: _titulocontrol,
                            textCapitalization: TextCapitalization.sentences,
                            decoration: _campo('Ej: Parcial Aplicación'),
                          ),
                        ],
                      ),
                  ),
                ],
              ),
            ),

            SizedBox(height: 12),
            _seleccion(
                icono: Icons.calendar_month_rounded,
                titulo: "Fecha",
                valor: _dia == null ? null : fechalarga(_dia!),
                hint: "Selecciona una fecha",
                onTap: _elegirdia,
            ),

            SizedBox(height: 12),
            _seleccion(
              icono: Icons.access_time_rounded,
              titulo: "Hora",
              valor: _hora == null ? null : _textohora(_hora!),
              hint: "Selecciona una hora",
              onTap: _elegirhora,
            ),

            SizedBox(height: 12),
            _seleccion(
              icono: Icons.timelapse_rounded,
              titulo: "Hora de fin (opcional)",
              valor: _fin == null ? null : _textohora(_hora!),
              hint: "Sin hora de fin",
              onTap: _elegirfin,
              onLimpiar: () => setState(() => _fin = null),
            ),

            SizedBox(height: 12),
            Container(
              padding: EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _icono(Icons.location_on_rounded),

                  SizedBox(width: 12),
                  Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Lugar (opcional)",
                              style: GoogleFonts.fredoka(fontSize: 17, fontWeight: FontWeight.w700, color: moradoOscuro),
                          ),

                          SizedBox(height: 6),
                          TextField(
                            controller: _lugarcontrol,
                            textCapitalization: TextCapitalization.sentences,
                            decoration: _campo('Ej: Aula 204'),
                          ),
                        ],
                      )
                  ),
                ],
              ),
            ),

            SizedBox(height: 20),
            Text("Categoría",
              style: GoogleFonts.fredoka(fontSize: 17, fontWeight: FontWeight.w700, color: moradoOscuro),
            ),

            SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: List.generate(categoriasagenda.length, (i){
                final c = categoriasagenda[i];
                final activa = i == _categoria;

                return GestureDetector(
                    onTap: () => setState(() => _categoria = i),
                    child: Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        color: c.color,
                        shape: BoxShape.circle,
                        border: activa ? Border.all(color: moradoOscuro, width: 3) : null,
                      ),
                      child: activa
                          ?Icon(Icons.check_rounded, color: Colors.white)
                          :null,
                    ),
                );
              }),
            ),

            SizedBox(height: 8),
            Text(categoriasagenda[_categoria].nombre,
              style: GoogleFonts.poppins(fontSize: 13, fontWeight: FontWeight.w600,
                color: categoriasagenda[_categoria].color),
            ),

            SizedBox(height: 20),
            Container(
              padding: EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Descripción (opcional)",
                      style: GoogleFonts.fredoka(fontSize: 17, fontWeight: FontWeight.w700, color: moradoOscuro,
                      )
                  ),

                  SizedBox(height: 8),
                  TextField(
                    controller: _descripcioncontrol,
                    minLines: 4,
                    maxLines: 6,
                    textCapitalization: TextCapitalization.sentences,
                    decoration: _campo("Agrega más detalles..."),
                  ),
                ],
              ),
            ),

            SizedBox(height: 28),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _guardar,
                style: ElevatedButton.styleFrom(
                  backgroundColor: morado,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(26),
                  ),
                ),
                child: Text(_editando ? "Guardar cambios" : "Guardar evento",
                  style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w600),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
