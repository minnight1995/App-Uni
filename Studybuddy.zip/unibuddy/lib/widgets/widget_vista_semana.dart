import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/cartas/carta_evento.dart';
import 'package:unibuddy/utilidades/agenda.dart';
import 'package:unibuddy/utilidades/eventos.dart';

class WidgetVistaSemana extends StatelessWidget {
  final DateTime dia;
  final List<ItemAgenda> Function(DateTime) itemsDe;
  final VoidCallback onAnterior;
  final VoidCallback onSiguiente;
  final void Function(DateTime) onAgregar;
  final void Function(ItemAgenda) onTapItem;

  const WidgetVistaSemana({
    super.key,
    required this.dia,
    required this.itemsDe,
    required this.onAnterior,
    required this.onSiguiente,
    required this.onAgregar,
    required this.onTapItem,
  });

  static const _morado = Color(0xFF4A2FBD);
  static const _oscuro = Color(0xFF35147D);

  @override
  Widget build(BuildContext context) {
    final lunes = lunesdelasemana(dia);
    final dias = List.generate(7, (i) => sumardias(lunes, i));

    return Column(
      children: [
        Padding(
            padding: EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                onPressed: onAnterior,
                icon: Icon(Icons.chevron_left_rounded, color: _oscuro, size: 30),
              ),

              Flexible(
                child: Text("Semana del ${rangosemana(lunes)}",
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.fredoka(fontSize: 19, fontWeight: FontWeight.w600, color: _oscuro,
                  ),
                ),
              ),
              IconButton(
                onPressed: onSiguiente,
                icon: Icon(Icons.chevron_right_rounded, color: _oscuro, size: 30),
              ),
            ],
          ),
        ),

        Expanded(
            child: ListView(
              padding: EdgeInsets.fromLTRB(16, 4, 20, 90),
              children: [for (final d in dias) _fila(d)],
            )
        ),
      ],
    );
  }

  Widget _fila(DateTime d) {
    final items = itemsDe(d);
    final eshoy = mismodia(d, DateTime.now());

    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SizedBox(
            width: 56,
            child: Align(
              alignment: Alignment.topCenter,
              child: Container(
                width: 48,
                padding: EdgeInsets.symmetric(vertical: 6),
                decoration: BoxDecoration(
                  color: eshoy ? _morado : Colors.transparent,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(nombresdias[d.weekday - 1].substring(0, 3),
                      style: GoogleFonts.poppins(fontSize: 12, fontWeight: FontWeight.w500, color: eshoy ? Colors.white : _oscuro),
                    ),
                    Text("${d.day}",
                      style: GoogleFonts.fredoka(fontSize: 18, fontWeight: FontWeight.w700, color: eshoy ? Colors.white : _oscuro,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          Expanded(
            child: Container(
              margin: EdgeInsets.only(left: 6),
              padding: EdgeInsets.only(left: 12, bottom: 12),
              decoration: BoxDecoration(
                border: Border(
                  left: BorderSide(
                    color: _morado.withOpacity(0.25),
                    width: 2,
                  ),
                ),
              ),
              child: items.isEmpty
                  ? _vacio(d)
                  : Column(
                children: [
                  for (var i = 0; i < items.length; i++) ...[
                    if (i > 0) SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      child: CartaEvento(
                        item: items[i],
                        compacta: true,
                        onTap: () => onTapItem(items[i]),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _vacio(DateTime d) {
    return Material(
      color: _morado.withOpacity(0.06),
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => onAgregar(d),
        child: SizedBox(
          width: double.infinity,
          height: 52,
          child: Center(
            child: Icon(Icons.add_rounded, color: _morado.withOpacity(0.35), size: 22),
          ),
        ),
      ),
    );
  }
}
