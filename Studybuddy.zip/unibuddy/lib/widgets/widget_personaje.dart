import 'package:unibuddy/api.dart';

String imagenPersonaje(int? genero) {
  switch (genero) {
    case 0:
      return "assets/images/hombre.png";
    case 1:
      return "assets/images/mujer.png";
    default:
      return "assets/images/buddy.png";
  }
}

String? _imagenGuardada;

Future<String> cargarPersonaje() async {
  if (_imagenGuardada != null) return _imagenGuardada!;

  final token = await leerToken();
  if (token == null) return imagenPersonaje(null);

  final datos = await obtenerPerfil(token);
  if (datos['error'] != null) return imagenPersonaje(null);

  _imagenGuardada =
      imagenPersonaje(int.tryParse("${datos['genero'] ?? ''}"));
  return _imagenGuardada!;
}

void limpiarPersonaje() => _imagenGuardada = null;