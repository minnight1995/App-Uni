import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/cartas/carta_evento.dart';
import 'package:unibuddy/utilidades/agenda.dart';
import 'package:unibuddy/utilidades/eventos.dart';
import 'package:unibuddy/widgets/widget_personaje.dart';

class WidgetVistaDia extends StatelessWidget {
  final DateTime dia;
  final List<ItemAgenda> items;
  final VoidCallback onAnterior;
  final VoidCallback onSiguiente;
  final VoidCallback onAgregar;
  final void Function(ItemAgenda) onTapItem;

  const WidgetVistaDia({
    super.key,
    required this.dia,
    required this.items,
    required this.onAnterior,
    required this.onSiguiente,
    required this.onAgregar,
    required this.onTapItem,
  });

  static const _morado = Color(0xFF4A2FBD);
  static const _oscuro = Color(0xFF35147D);

  String get _mensaje {
    final cuando = mismodia(dia, DateTime.now()) ? "hoy" : "este día";
    if (items.isEmpty) return 'No tienes actividades $cuando';
    final n = items.length;
    return "¡Tienes $n ${n == 1 ? "actividad" : "actividades"} $cuando!";
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: EdgeInsetsGeometry.fromLTRB(12, 0, 12, 0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                onPressed: onAnterior,
                icon: Icon(Icons.chevron_left_rounded, color: _oscuro, size: 30),
              ),
              Text(fechadia(dia),
                style: GoogleFonts.fredoka(fontSize: 20, fontWeight: FontWeight.w600, color: _oscuro),
              ),

              IconButton(
                onPressed: onSiguiente,
                icon: Icon(Icons.chevron_right_rounded, color: _oscuro, size: 30),
              ),
            ],
          ),
        ),

        Expanded(
            child: ListView(
              padding: EdgeInsetsGeometry.fromLTRB(20, 0, 20, 12),
              children: [
                Row(
                  children: [
                    SizedBox(
                      width: 110,
                      height: 110,
                      child: FutureBuilder<String>(
                        future: cargarPersonaje(),
                        builder: (context, snap) => Image.asset(
                          snap.data ?? "assets/images/personaje_buddy.png",
                          height: 220,
                        ),
                      ),
                    ),

                    SizedBox(width: 8),
                    Expanded(
                      child: Container(
                        padding: EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 10,
                              offset: Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Text(_mensaje,
                          style: GoogleFonts.fredoka(fontSize: 16, fontWeight: FontWeight.w600, color: _oscuro),
                        ),
                      ),
                    ),
                  ],
                ),

                SizedBox(height: 16),
                for (var i = 0; i < items.length; i++)
                  _fila(items[i], ultimo: i == items.length - 1),
              ],
            ),
        ),
        Padding(
            padding: EdgeInsets.fromLTRB(20, 4, 20, 16),
          child: SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton.icon(
                onPressed: onAgregar,
                icon: Icon(Icons.add_rounded,size: 26),
                label: Text("Agregar evento",
                  style: GoogleFonts.poppins(fontSize: 17, fontWeight: FontWeight.w600),
                ),
              style: ElevatedButton.styleFrom(
                backgroundColor: _morado,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(26),
                ),
              ),
            ),
          ),
        )
      ],
    );
  }

  Widget _fila(ItemAgenda it, {required bool ultimo}) {
    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SizedBox(
            width: 66,
            child: Padding(
              padding: EdgeInsets.only(top: 18),
              child: Text(horaampm(it.inicio),
                style: GoogleFonts.poppins(fontSize: 12.5, fontWeight: FontWeight.w600, color: _oscuro),
              ),
            ),
          ),

          SizedBox(
            width: 22,
            child: Column(
              children: [

                SizedBox(height: 22),
                Container(
                  width: 10,
                  height: 10,
                  decoration:
                  BoxDecoration(color: it.color, shape: BoxShape.circle),
                ),
                if (!ultimo)
                  Expanded(
                    child: Container(
                      width: 2,
                      color: it.color.withOpacity(0.35),
                    ),
                  ),
              ],
            ),
          ),

          Expanded(
            child: Padding(
              padding: EdgeInsets.only(bottom: 12),
              child: CartaEvento(item: it, onTap: () => onTapItem(it)),
            ),
          ),
        ],
      ),
    );
  }
}
