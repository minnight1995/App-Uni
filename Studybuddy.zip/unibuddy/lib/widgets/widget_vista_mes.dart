import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/cartas/carta_evento.dart';
import 'package:unibuddy/utilidades/agenda.dart';
import 'package:unibuddy/utilidades/eventos.dart';

class WidgetVistaMes extends StatelessWidget {
  final DateTime dia;
  final List<ItemAgenda> Function(DateTime) itemsDe;
  final VoidCallback onAnterior;
  final VoidCallback onSiguiente;
  final void Function(DateTime) onSeleccionar;
  final VoidCallback onAgregar;
  final void Function(ItemAgenda) onTapItem;

  const WidgetVistaMes({
    super.key,
    required this.dia,
    required this.itemsDe,
    required this.onAnterior,
    required this.onSiguiente,
    required this.onSeleccionar,
    required this.onAgregar,
    required this.onTapItem,
  });

  static const _morado = Color(0xFF4A2FBD);
  static const _oscuro = Color(0xFF35147D);
  static const _letras = ["L", "M", "X", "J", "V", "S", "D"];

  @override
  Widget build(BuildContext context) {
    final primero = DateTime(dia.year, dia.month, 1);
    final diasDelMes = DateTime(dia.year, dia.month + 1, 0).day;
    final semanas = ((primero.weekday - 1 + diasDelMes) / 7).ceil();
    final inicio = lunesdelasemana(primero);
    final items = itemsDe(dia);
    final eshoy = mismodia(dia, DateTime.now());

    return Column(
      children: [
        Expanded(
            child: ListView(
              padding: EdgeInsets.fromLTRB(20, 0, 20, 12),
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      onPressed: onAnterior,
                      icon: Icon(Icons.chevron_left_rounded, color: _oscuro, size: 30),
                    ),
                    Text(mesyanio(dia),
                      style: GoogleFonts.fredoka(fontSize: 20, fontWeight: FontWeight.w600, color: _oscuro),
                    ),
                    IconButton(
                      onPressed: onSiguiente,
                      icon: Icon(Icons.chevron_right_rounded, color: _oscuro, size: 30),
                    ),
                  ],
                ),

                Row(
                  children: [
                    for (final l in _letras)
                      Expanded(
                        child: Center(
                          child: Text(l,
                            style: GoogleFonts.poppins(fontSize: 13, fontWeight: FontWeight.w600, color: _oscuro.withOpacity(0.7)),
                          ),
                        ),
                      ),
                  ],
                ),

                SizedBox(height: 6),
                for (var s = 0; s < semanas; s++)
                  Row(
                    children: [
                      for (var i = 0; i < 7; i++)
                        _celda(
                          sumardias(inicio, s * 7 + i),
                          sumardias(inicio, s * 7 + i).month == dia.month,
                        ),
                    ],
                  ),

                SizedBox(height: 16),
                Text(
                  eshoy ? "Hoy, ${fechadia(dia)}" : fechalarga(dia),
                  style: GoogleFonts.fredoka(fontSize: 18, fontWeight: FontWeight.w700, color: _oscuro),
                ),

                SizedBox(height: 12),
                if (items.isEmpty)
                  Padding(
                    padding: EdgeInsets.symmetric(vertical: 16),
                    child: Text("No hay actividades este día",
                      textAlign: TextAlign.center,
                      style: GoogleFonts.poppins(fontSize: 14, color: _oscuro.withOpacity(0.6)),
                    ),
                  )
                else
                  for (final it in items)
                    Padding(
                      padding: EdgeInsets.only(bottom: 12),
                      child: Row(
                        children: [
                          SizedBox(
                            width: 66,
                            child: Text(horaampm(it.inicio),
                              style: GoogleFonts.poppins(fontSize: 12.5, fontWeight: FontWeight.w600, color: _oscuro),
                            ),
                          ),

                          Expanded(
                            child: CartaEvento(
                                item: it, onTap: () => onTapItem(it)),
                          ),
                        ],
                      ),
                    ),
              ],
            ),
        ),

        Padding(
          padding: EdgeInsets.fromLTRB(20, 4, 20, 16),
          child: SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton.icon(
                onPressed: onAgregar,
                icon: Icon(Icons.add_rounded, size: 26),
                label: Text("Agregar evento",
                  style: GoogleFonts.poppins(fontSize: 17, fontWeight: FontWeight.w600),
                ),
              style: ElevatedButton.styleFrom(
                backgroundColor: _morado,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(26),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _celda(DateTime d, bool delMes) {
    final sel = mismodia(d, dia);
    final hoy = mismodia(d, DateTime.now());

    final colores = <Color>[];
    for (final it in itemsDe(d)) {
      if (!colores.contains(it.color)) colores.add(it.color);
      if (colores.length == 3) break;
    }

    return Expanded(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => onSeleccionar(d),
        child: Opacity(
          opacity: delMes ? 1 : 0.35,
          child: SizedBox(
            height: 52,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 34,
                  height: 34,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: sel ? _morado : null,
                    shape: BoxShape.circle,
                    border: (hoy && !sel)
                        ? Border.all(color: _morado, width: 1.5)
                        : null,
                  ),
                  child: Text("${d.day}",
                    style: GoogleFonts.fredoka(fontSize: 16, fontWeight: FontWeight.w600, color: sel ? Colors.white : _oscuro,
                    ),
                  ),
                ),

                SizedBox(height: 3),
                SizedBox(
                  height: 6,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      for (final c in colores)
                        Container(
                          width: 6,
                          height: 6,
                          margin: EdgeInsets.symmetric(horizontal: 1.5),
                          decoration:
                          BoxDecoration(
                              color: c,
                              shape: BoxShape.circle
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
