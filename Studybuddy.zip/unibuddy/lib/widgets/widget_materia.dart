import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class WidgetMateria extends StatelessWidget {
  final List<String> opciones;
  final int indice;
  final ValueChanged<int> onCambio;

  const WidgetMateria({
    super.key,
    required this.opciones,
    required this.indice,
    required this.onCambio
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
      ),
      child: Row(
        children: List.generate(opciones.length, (i){
          final activa = i == indice;
          return Expanded(
              child: GestureDetector(
                onTap: () => onCambio(i),
                child: AnimatedContainer(
                  duration: Duration(milliseconds: 200),
                  padding: EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                    color: activa ? Color(0xFFE4D9F7) : Colors.transparent,
                    borderRadius: BorderRadius.circular(26),
                  ),
                  child: Text(opciones[i],
                    textAlign: TextAlign.center,
                    style: GoogleFonts.poppins(fontSize: 14, fontWeight: activa ? FontWeight.w700 : FontWeight.w500,
                      color: Color(0xFF35147D),
                    ),
                  ),
                ),
              )
          );
        }),
      ),
    );
  }
}
