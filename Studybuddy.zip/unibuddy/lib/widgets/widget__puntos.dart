import 'package:flutter/material.dart';

class Puntos extends StatelessWidget {
  final int activo;
  final int total;

  const Puntos({super.key, required this.activo, this.total = 4});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(total, (index) {
        final esActivo = index == activo;
        return AnimatedContainer(
          duration: Duration(milliseconds: 300),
          margin: EdgeInsets.symmetric(horizontal: 4),
          width: esActivo ? 12 : 10,
          height: esActivo ? 12 : 10,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: esActivo ? Color(0xFF7B5CD6) : Color(0xFFB9A5EE),
          ),
        );
      }),
    );
  }
}