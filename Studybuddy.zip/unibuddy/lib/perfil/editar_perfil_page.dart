import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/api.dart';
import 'package:unibuddy/barras/barra_navegacion.dart';
import 'package:unibuddy/widgets/widget_personaje.dart';

class EditarPerfilPage extends StatefulWidget {
  const EditarPerfilPage({super.key});

  @override
  State<EditarPerfilPage> createState() => _EditarPerfilPageState();
}

class _EditarPerfilPageState extends State<EditarPerfilPage> {
  final _nombrecontrol = TextEditingController();
  final _correocontrol = TextEditingController();
  bool _guardando = false;
  static const _morado = Color(0xFF35147D);
  static const _moradoClaro = Color(0xFF6B6BBF);
  static const _acento = Color(0xFF7957EA);
  String _imagen = "assets/images/personaje_buddy.png";

  @override
  void initState() {
    super.initState();
    cargarPerfil();
    cargarPersonaje().then((img) {
      if (mounted) setState(() => _imagen = img);
    });
  }

  @override
  void dispose() {
    _nombrecontrol.dispose();
    _correocontrol.dispose();
    super.dispose();
  }

  Future<void> cargarPerfil() async {
    final token = await leerToken();
    if (token == null) return;

    final datos = await obtenerPerfil(token);
    if (!mounted || datos['error'] != null) return;

    _nombrecontrol.text = (datos['nombre'] ?? '').toString().trim();
    _correocontrol.text = (datos['correo'] ?? '').toString().trim();
  }

  void _mensaje(String texto) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(texto)));
  }

  Future<void> _guardar() async {
    final nombre = _nombrecontrol.text.trim();
    final correo = _correocontrol.text.trim();

    if (nombre.isEmpty) {
      _mensaje("Escribe tu nombre");
      return;
    }
    if (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(correo)) {
      _mensaje("Escribe un correo válido");
      return;
    }

    final token = await leerToken();
    if (token == null) return;

    setState(() => _guardando = true);

    final r = await actualizarPerfil(token, nombre, correo);

    if (!mounted) return;
    setState(() => _guardando = false);

    if (r['error'] != null) {
      _mensaje("No se pudo guardar: ${r['error']}");
      return;
    }

    _mensaje("Cambios guardados");
    Navigator.pop(context, true);
  }

  Widget _campo(String etiqueta, TextEditingController ctrl,
      {TextInputType tipo = TextInputType.text}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(etiqueta,
          style: GoogleFonts.fredoka(fontSize: 16, fontWeight: FontWeight.w700, color: _morado),
        ),

        SizedBox(height: 8),
        TextField(
          controller: ctrl,
          keyboardType: tipo,
          style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w500, color: _morado),
          decoration: InputDecoration(
            filled: true,
            fillColor: Colors.white,
            contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide(color: _acento.withOpacity(0.25)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide(color: _acento, width: 1.5),
            ),
          ),
        ),
      ],
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5EFFB),
      body: SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(24, 16, 24, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    IconButton(
                      padding: EdgeInsets.zero,
                      onPressed: () => Navigator.pop(context),
                      icon: Icon(Icons.arrow_back, color: _morado),
                    ),

                    Expanded(
                        child: Text("Editar perfil",
                          textAlign: TextAlign.center,
                          style: GoogleFonts.fredoka(fontSize: 20, fontWeight: FontWeight.w700, color: _morado),
                        ),
                    ),

                    SizedBox(width: 48),
                  ],
                ),

                SizedBox(height: 16),
                Center(
                  child: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Container(
                        width: 140,
                        height: 140,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                              color: _acento.withOpacity(0.25),
                              blurRadius: 18,
                              offset: Offset(0, 8),
                            ),
                          ],
                        ),
                    child: ClipOval(
                      child: Image.asset(_imagen, fit: BoxFit.cover),
                    ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 28),
                _campo("Nombre", _nombrecontrol),

                SizedBox(height: 18),
                _campo("Correo electrónico", _correocontrol, tipo: TextInputType.emailAddress),

                SizedBox(height: 32),
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: ElevatedButton(
                      onPressed: _guardando ? null : _guardar,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _acento,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(26)),
                      ),
                      child: _guardando
                          ?SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                      )
                          : Text("Guardar cambios",
                        style: GoogleFonts.poppins(fontSize: 15, fontWeight: FontWeight.w600, color: Colors.white),
                      ),
                  ),
                )
              ],
            ),
          ),
      ),

      bottomNavigationBar: BarraNavegacion(indice: 3),
    );
  }
}
