import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/api.dart';
import 'package:unibuddy/barras/barra_navegacion.dart';
import 'package:unibuddy/onboarding/iniciosesion_page.dart';
import 'package:unibuddy/widgets/widget_personaje.dart';

class CerrarSesionPage extends StatelessWidget {
  const CerrarSesionPage({super.key});

  static const _morado = Color(0xFF35147D);
  static const _acento = Color(0xFF7957EA);

  Future<void> _cerrarSesion(BuildContext context) async {
    await cerrarSesion();

    if (!context.mounted) return;
    Navigator.pushAndRemoveUntil(
      context, MaterialPageRoute(builder: (_) =>  IniciosesionPage()),
          (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5EFFB),
      body: SafeArea(
          child: Padding(
            padding: EdgeInsets.fromLTRB(24, 16, 24, 16),
            child: Column(
              children: [
                Row(
                  children: [
                    IconButton(
                      padding: EdgeInsets.zero,
                      onPressed: () => Navigator.pop(context),
                      icon: Icon(Icons.arrow_back, color: _morado),
                    ),

                    Expanded(
                        child: Text("Cerrar sesión",
                          textAlign: TextAlign.center,
                          style: GoogleFonts.fredoka(fontSize: 20, fontWeight: FontWeight.w700, color: _morado),
                        ),
                    ),

                    SizedBox(width: 48),
                  ],
                ),

                Spacer(),
                FutureBuilder<String>(
                  future: cargarPersonaje(),
                  builder: (context, snap) => Image.asset(
                    snap.data ?? "assets/images/personaje_buddy.png",
                    height: 220,
                  ),
                ),

                SizedBox(height: 24),
                Text("¿Estás seguro de que deseas cerrar sesión?",
                  textAlign: TextAlign.center,
                  style: GoogleFonts.fredoka(fontSize: 22, fontWeight: FontWeight.w700, color: _morado),
                ),

                SizedBox(height: 32),
                Row(
                  children: [
                    Expanded(
                        child: SizedBox(
                          height: 52,
                          child: OutlinedButton(
                            onPressed: () => Navigator.pop(context),
                            style: OutlinedButton.styleFrom(
                              side: BorderSide(color: _acento, width: 1.5),
                              backgroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(26)),
                            ),
                            child: Text("Cancelar",
                              style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w600, color: _acento),
                            ),
                          ),
                        ),
                    ),

                    SizedBox(width: 12),
                    Expanded(
                      child: SizedBox(
                        height: 52,
                        child: ElevatedButton(
                          onPressed: () => _cerrarSesion(context),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _acento,
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(26)),
                          ),
                          child: Text("Cerrar sesión",
                            style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),

                Spacer(),
              ],
            ),
          )
      ),

      bottomNavigationBar: BarraNavegacion(indice: 3),
    );
  }
}
