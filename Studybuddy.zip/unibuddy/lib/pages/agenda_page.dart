import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/agenda/agregar_clase.dart';
import 'package:unibuddy/agenda/agregar_evento.dart';
import 'package:unibuddy/agenda/detalle_evento.dart';
import 'package:unibuddy/agenda/horario_agenda.dart';
import 'package:unibuddy/api.dart';
import 'package:unibuddy/barras/barra_navegacion.dart';
import 'package:unibuddy/utilidades/agenda.dart';
import 'package:unibuddy/utilidades/eventos.dart';
import 'package:unibuddy/widgets/widget_materia.dart';
import 'package:unibuddy/widgets/widget_vista_dia.dart';
import 'package:unibuddy/widgets/widget_vista_mes.dart';
import 'package:unibuddy/widgets/widget_vista_semana.dart';

class AgendaPage extends StatefulWidget {
  const AgendaPage({super.key});

  @override
  State<AgendaPage> createState() => _AgendaPageState();
}

class _AgendaPageState extends State<AgendaPage> {
  int _seccion = 1;
  bool _cargando = true;
  final List<Map<String, dynamic>> materias = [];
  final List<Map<String, dynamic>> clases = [];
  final List<Map<String, dynamic>> eventos = [];
  int _vista = 2;
  DateTime _dia = DateTime.now();

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async {
    final token = await leerToken();
    if (token == null) {
      if (mounted) setState(() => _cargando = false);
      return;
    }

    final pedidomaterias = listarMaterias(token);
    final pedidoclases = listarClases(token);
    final pedidoeventos = listarEventos(token);
    final listamaterias = await pedidomaterias;
    final listaclases = await pedidoclases;
    final listaeventos = await pedidoeventos;

    if (!mounted) return;

    setState(() {
      _cargando = false;
      if (listamaterias != null) {
        materias
          ..clear()
          ..addAll(listamaterias);
      }
      if (listaclases != null) {
        clases
          ..clear()
          ..addAll(listaclases);
      }
      if (listaeventos != null) {
        eventos..clear()..addAll(listaeventos);
      }
    });
  }

  Future<void> _agregarClase() async {
    if (materias.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Primero crea una materia en la pestaña Materias'),
        ),
      );
      return;
    }

    final datos = await Navigator.push<Map<String, dynamic>>(
      context,
      MaterialPageRoute(builder: (_) => AgregarClase(materias: materias)),
    );
    if (datos == null) return;

    final token = await leerToken();
    if (token == null) return;

    final r = await crearClases(
      token: token,
      materiaId: datos["materia_id"],
      dias: List<int>.from(datos["dias"]),
      inicio: datos["inicio"],
      fin: datos["fin"],
      salon: datos["salon"],
    );
    if (!mounted) return;

    if (r.containsKey("error")) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(r["error"])),
      );
      return;
    }
    setState(() {
      clases.addAll(List<Map<String, dynamic>>.from(r["clases"]));
    });
  }

  Future<void> _agregarevento([DateTime? dia]) async {
    final datos = await Navigator.push<Map<String, dynamic>>(
      context, MaterialPageRoute(builder: (_) => AgregarEvento(fechaInicial: dia)),
    );
    if (datos == null) return;

    final token = await leerToken();
    if (token == null) return;

    final r = await crearEvento(
      token: token,
      titulo: datos["titulo"],
      categoria: datos["categoria"],
      inicio: datos["inicio"],
      fin: datos["fin"],
      lugar: datos["lugar"],
      descripcion: datos["descripcion"],
    );
    if (!mounted) return;

    if (r.containsKey("error")) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(r["error"])),
      );
      return;
    }
    setState(() => eventos.add(r));
  }

  Future<void> _abrirdetalle(ItemAgenda item) async {
    final accion = await Navigator.push<String>(
      context, MaterialPageRoute(builder: (_) => DetalleEvento(item: item)));
    if (accion == "editar") await _editarevento(item);
    if (accion == "eliminar") await _borrarevento(item);
  }
  void _cambiarmes(int delta) {
    final n = DateTime(_dia.year, _dia.month + delta, 1);
    final hoy = DateTime.now();
    setState(() {
      _dia = (n.year == hoy.year && n.month == hoy.month) ? hoy : n;
    });
  }
  Future<void> _editarevento(ItemAgenda item) async {
    final datos = await Navigator.push<Map<String, dynamic>>(
      context, MaterialPageRoute(builder: (_) => AgregarEvento(evento: item.datos)));
    if (datos == null) return;

    final token = await leerToken();
    if (token == null) return;

    final r = await actualizarEvento(
      token: token,
      id: item.id,
      titulo: datos["titulo"],
      categoria: datos["categoria"],
      inicio: datos["inicio"],
      fin: datos["fin"],
      lugar: datos["lugar"],
      descripcion: datos["descripcion"],
    );
    if (!mounted) return;

    if (r.containsKey("error")) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(r["error"])));
      return;
    }
    setState(() {
      final i = eventos.indexWhere((e) => e["id"] == item.id);
      if (i != -1) eventos[i] = r;
    });
  }

  Future<void> _borrarevento(ItemAgenda item) async {
    final token = await leerToken();
    if (token == null) return;

    final r = await borrarEvento(token, item.id);
    if (!mounted) return;

    if (r.containsKey('error')) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(r['error'])));
      return;
    }
    setState(() => eventos.removeWhere((e) => e['id'] == item.id));
  }

  Future<void> _borrarClase(Map<String, dynamic> c) async {
    final seguro = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text("Borrar clase"),
        content: Text("¿Quieres borrar esta clase del horario?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text("Cancelar"),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text("Borrar"),
          ),
        ],
      ),
    );
    if (seguro != true) return;

    final token = await leerToken();
    if (token == null) return;

    final r = await borrarClase(token, c["id"]);
    if (!mounted) return;

    if (r.containsKey("error")) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(r["error"])),
      );
      return;
    }
    setState(() => clases.remove(c));
  }

  void _opcionesClase(Map<String, dynamic> c) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: EdgeInsets.fromLTRB(20, 16, 20, 12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: Icon(Icons.edit_rounded, color: Color(0xFF4A2FBD)),
                title: Text("Editar clase",
                    style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
                onTap: () {
                  Navigator.pop(ctx);
                  _editarClase(c);
                },
              ),
              ListTile(
                leading: Icon(Icons.delete_rounded, color: Colors.red),
                title: Text("Eliminar clase",
                    style: GoogleFonts.poppins(fontWeight: FontWeight.w600, color: Colors.red)),
                onTap: () {
                  Navigator.pop(ctx);
                  _borrarClase(c);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _editarClase(Map<String, dynamic> c) async {
    final datos = await Navigator.push<Map<String, dynamic>>(
      context,
      MaterialPageRoute(
        builder: (_) => AgregarClase(materias: materias, clase: c),
      ),
    );
    if (datos == null) return;

    final token = await leerToken();
    if (token == null) return;

    final r = await actualizarClase(
      token: token,
      id: c["id"],
      materiaId: datos["materia_id"],
      dia: datos["dia"],
      inicio: datos["inicio"],
      fin: datos["fin"],
      salon: datos["salon"],
    );
    if (!mounted) return;

    if (r.containsKey("error")) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(r["error"])),
      );
      return;
    }
    setState(() {
      final i = clases.indexWhere((x) => x["id"] == c["id"]);
      if (i != -1) clases[i] = r;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5EFFB),
      floatingActionButton: (_seccion == 0 && _vista ==1)
          ? FloatingActionButton(
        backgroundColor: const Color(0xFF4A2FBD),
        foregroundColor: Colors.white,
        shape: const CircleBorder(),
        onPressed: () => _agregarevento(_dia),
        child: const Icon(Icons.add, size: 30),
      )
          : null,
      body: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                  padding: EdgeInsetsGeometry.fromLTRB(24, 24, 24, 0),
                child: Text("Mi Agenda",
                  style: GoogleFonts.fredoka(fontSize: 26, fontWeight: FontWeight.w800, color: Color(0xFF35147D)),
                ),
              ),

              SizedBox(height: 12),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 24),
                child: WidgetMateria(
                    opciones: ["Calendario", "Horario"],
                    indice: _seccion,
                    onCambio: (i) => setState(() => _seccion = i),
                ),
              ),

              SizedBox(height: 12),
              Expanded(
                  child: _cargando
                      ?Center(child: CircularProgressIndicator())
                      :_seccion == 0
                      ?Column(
                    children: [
                      Padding(
                          padding: EdgeInsets.symmetric(horizontal: 24),
                        child: WidgetMateria(
                          opciones: ["Mes", "Semana", "Día"],
                          indice: _vista,
                          onCambio: (i) => setState(() => _vista = i),
                        ),
                      ),

                      SizedBox(height: 12),
                      Expanded(
                        child: _vista == 2
                            ? WidgetVistaDia(
                          dia: _dia,
                          items: itemsdeldia(
                            dia: _dia,
                            clases: clases,
                            materias: materias,
                            eventos: eventos,
                          ),
                          onAnterior: () => setState(() => _dia = sumardias(_dia, -1)),
                          onSiguiente: () => setState(() => _dia = sumardias(_dia, 1)),
                          onAgregar: () => _agregarevento(_dia),
                          onTapItem: _abrirdetalle,
                        )
                            :_vista == 1
                        ?WidgetVistaSemana(
                          dia: _dia,
                          itemsDe: (d) => itemsdeldia(
                            dia: d,
                            clases: clases,
                            materias: materias,
                            eventos: eventos,
                          ),
                          onAnterior: () => setState(() => _dia = sumardias(_dia, -7)),
                          onSiguiente: () => setState(() => _dia = sumardias(_dia, 7)),
                          onAgregar: _agregarevento,
                          onTapItem: _abrirdetalle,
                        )
                            : WidgetVistaMes(
                          dia: _dia,
                          itemsDe: (d) => itemsdeldia(
                            dia: d,
                            clases: clases,
                            materias: materias,
                            eventos: eventos,
                          ),
                          onAnterior: () => _cambiarmes(-1),
                          onSiguiente: () => _cambiarmes(1),
                          onSeleccionar: (d) => setState(() => _dia = d),
                          onAgregar: () => _agregarevento(_dia),
                          onTapItem: _abrirdetalle,
                        ),                      ),
                    ],
                  )
                      :HorarioAgenda(
                    materias: materias,
                    clases: clases,
                    onAgregar: _agregarClase,
                    onOpciones: _opcionesClase,
                  ),
              ),
            ],
          )
      ),

      bottomNavigationBar: BarraNavegacion(indice: 2),
    );
  }
}
