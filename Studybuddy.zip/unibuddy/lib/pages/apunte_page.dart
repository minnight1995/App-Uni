import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ApuntePage extends StatefulWidget {
  final Map<String, dynamic>? apunte;

  const ApuntePage({
    super.key,
    required this.apunte,
  });

  @override
  State<ApuntePage> createState() => _ApuntePageState();
}

class _ApuntePageState extends State<ApuntePage> {
  static const morado = Color(0xFF4A2FBD);
  static const moradoOscuro = Color(0xFF35147D);
  late final TextEditingController _titulocontrol;
  late final TextEditingController _contenidocontrol;
  bool get _editando => widget.apunte != null;

  @override
  void initState() {
    super.initState();
    _titulocontrol = TextEditingController(text: widget.apunte?["titulo"] ?? "");
    _contenidocontrol = TextEditingController(text: widget.apunte?["contenido"] ?? "");
  }

  @override
  void dispose() {
    _titulocontrol.dispose();
    _contenidocontrol.dispose();
    super.dispose();
  }

  void _guardar() {
    final titulo = _titulocontrol.text.trim();
    if (titulo.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Escribe un título para el apunte")),
      );
      return;
    }
    Navigator.pop(context, {
      "accion": "guardar",
      "titulo": titulo,
      "contenido": _contenidocontrol.text.trim(),
    });
  }

  Future<void> _borrar() async {
    final seguro = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("Borrar apunte"),
        content: Text("¿Seguro que quieres borrar este apunte?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text("Cancelar"),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text("Borrar"),
          ),
        ],
      ),
    );
    if (seguro == true && mounted) {
      Navigator.pop(context, {"accion": "borrar"});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5EFFB),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        foregroundColor: moradoOscuro,
        title: Text(_editando ? "Editar apunte" : "Nuevo apunte",
          style: GoogleFonts.fredoka(fontSize: 22, fontWeight: FontWeight.w600, color: moradoOscuro,
          ),
        ),
        actions: [
          if (_editando)
            IconButton(
              icon: Icon(Icons.delete_outline_rounded),
              onPressed: _borrar,
            ),
          IconButton(
            icon: Icon(Icons.check_rounded, color: morado, size: 28),
            onPressed: _guardar,
          ),
        ],
      ),
      body: Padding(
          padding: EdgeInsetsGeometry.fromLTRB(20, 0, 20, 20),
        child: Container(
          padding: EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(22),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 10,
                offset: Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            children: [
              TextField(
                controller: _titulocontrol,
                textCapitalization: TextCapitalization.sentences,
                style: GoogleFonts.fredoka(fontSize: 24, fontWeight: FontWeight.w700, color: moradoOscuro,
                ),
                decoration: InputDecoration(
                  hintText: "Título",
                  hintStyle: GoogleFonts.fredoka(fontSize: 24, fontWeight: FontWeight.w700, color: moradoOscuro.withOpacity(0.35),
                  ),
                  border: InputBorder.none,
                ),
              ),

              Divider(),
              Expanded(
                  child: TextField(
                    controller: _contenidocontrol,
                    expands: true,
                    maxLines: null,
                    textAlignVertical: TextAlignVertical.top,
                    keyboardType: TextInputType.multiline,
                    textCapitalization: TextCapitalization.sentences,
                    style: GoogleFonts.poppins(fontSize: 15, color: moradoOscuro,
                    ),
                    decoration: InputDecoration(
                      hintText: "Escribe tu apunte aquí...",
                      hintStyle: GoogleFonts.poppins(
                        fontSize: 15,
                        color: moradoOscuro.withOpacity(0.35),
                      ),
                      border: InputBorder.none,
                    ),
                  )
              ),
            ],
          ),
        ),
      ),
    );
  }
}
