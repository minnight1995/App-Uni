import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/barras/barra_busqueda.dart';
import 'package:unibuddy/barras/barra_navegacion.dart';
import 'package:unibuddy/cartas/carta_materia.dart';
import 'package:unibuddy/materia/agregar_materia.dart';
import 'package:unibuddy/materia/detalle_materia.dart';
import 'package:unibuddy/utilidades/opciones_materia.dart';
import 'package:unibuddy/api.dart';

class MateriasPage extends StatefulWidget {
  const MateriasPage({super.key});

  @override
  State<MateriasPage> createState() => _MateriasPageState();
}

class _MateriasPageState extends State<MateriasPage> {
  String _filtro = "";
  final List<Map<String, dynamic>> materias = [];
  bool _cargando = true;

  @override
  void initState(){
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async{
    final token = await leerToken();
    final lista = token == null ? null : await listarMaterias(token);
    if(!mounted) return;

    setState(() {
      _cargando = false;
      if(lista != null){
        materias
        ..clear()
            ..addAll(lista);
      }
    });

    if(lista == null){
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("No se pudieron cargar las materias"))
      );
    }
  }

Future<void> _agregarMateria() async{
    final nueva = await Navigator.push<Map<String, dynamic>>(
        context,
        MaterialPageRoute(builder: (_) => AgregarMateria())
    );

    if (nueva == null) return;

    final token = await leerToken();
    if (token == null) return;

    final guardada = await crearMateria(
      token: token,
      nombre: nueva['nombre'],
      profesor: nueva['profesor'],
      icono: nueva['icono'],
      color: nueva['color'],
    );
    if (!mounted) return;

    if (guardada.containsKey('error')) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(guardada['error'])),
      );
      return;
    }
    setState(() => materias.insert(0, guardada));
}

  @override
  Widget build(BuildContext context) {
    final visibles = materias.where((m) {
      return m['nombre']
          .toString()
          .toLowerCase()
          .contains(_filtro.toLowerCase());
    }).toList();

    return Scaffold(
      backgroundColor: Color(0xFFF5EFFB),
      body: SafeArea(
          child: Padding(
              padding: EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    SizedBox(height: 30),
                    Text( "Mis Materias",
                      style: GoogleFonts.fredoka(fontSize: 26, fontWeight: FontWeight.w800, color: Color(0xFF35147D)),
                    ),
                  ],
                ),

                SizedBox(height: 12),
                BarraBusqueda(
                  onCambio: (texto) => setState(() => _filtro = texto),
                  onAgregar: _agregarMateria,
                ),

                SizedBox(height: 15),
                Expanded(
                    child: _cargando
                    ?Center(child: CircularProgressIndicator())
                    :visibles.isEmpty
                        ?Center(
                      child: Text(materias.isEmpty
                          ?"Aun no tienes materias. Toca + para agregar una."
                          :"No se encontraron materias.",
                        textAlign: TextAlign.center,
                        style: GoogleFonts.poppins(fontSize: 12, fontWeight: FontWeight.w500, color: Color(0xFF5245AE)),
                      ),
                    )
                        :ListView.separated(
                        itemBuilder: (context, i){
                          final m = visibles[i];
                          return CartaMateria(
                              materia: m["nombre"],
                              profesor: m["profesor"] == ""
                              ? "Sin profesor"
                              :m["profesor"],
                              icono: listaiconos[m["icono"]],
                              color: Color(m["color"]),
                            progreso: (m["progreso"] ?? 0.0).toDouble(),
                            onTap: () async{
                              await Navigator.push(context, MaterialPageRoute(builder: (_) => DetalleMateria(materia: m))
                              );
                              if (mounted) setState(() {});
                            }
                          );
                        },
                        separatorBuilder: (_, __) => SizedBox(height: 12),
                        itemCount: visibles.length),
                ),
              ],
            ),
          ),
      ),
      bottomNavigationBar: BarraNavegacion(indice: 1),
    );
  }
}
