import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/api.dart';
import 'package:unibuddy/barras/barra_navegacion.dart';
import 'package:unibuddy/perfil/cerrar_sesion_page.dart';
import 'package:unibuddy/perfil/editar_perfil_page.dart';
import 'package:unibuddy/widgets/widget_personaje.dart';


class PerfilPage extends StatefulWidget {
  const PerfilPage({super.key});

  @override
  State<PerfilPage> createState() => _PerfilPageState();
}

class _PerfilPageState extends State<PerfilPage> {
  String nombre = "";
  String correo = "";
  static const _morado = Color(0xFF35147D);
  static const _moradoClaro = Color(0xFF6B6BBF);
  static const _acento = Color(0xFF7957EA);
  String _imagen = "assets/images/personaje.png";


  @override
  void initState() {
    super.initState();
    cargarPerfil();
    cargarPersonaje().then((img) {
      if (mounted) setState(() => _imagen = img);
    });
  }

  Future<void> cargarPerfil() async {
    final token = await leerToken();
    if (token == null) return;

    final datos = await obtenerPerfil(token);
    if (!mounted || datos['error'] != null) return;

    setState(() {
      nombre = (datos['nombre'] ?? '').toString().trim();
      correo = (datos['correo'] ?? '').toString().trim();
    });
  }

  Widget _avatar() {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          width: 220,
          height: 220,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: _acento.withOpacity(0.25),
                blurRadius: 18,
                offset: Offset(0, 8),
              ),
            ],
          ),
          child: ClipOval(
            child: Image.asset(_imagen, fit: BoxFit.cover),
          ),
        ),
        Positioned(
          right: 0,
          bottom: 4,
          child: GestureDetector(
            onTap: () async {
              await Navigator.push(
                context, MaterialPageRoute(builder: (_) => EditarPerfilPage()),
              );
              cargarPerfil();
            },
            child: Container(
              padding: EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: _acento.withOpacity(0.25),
                    blurRadius: 8,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
              child: Icon(Icons.edit, color: _acento, size: 35),
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5EFFB),
      body: SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(24, 16, 24, 16),
            child: Column(
              children: [

                SizedBox(height: 150),
                _avatar(),

                SizedBox(height: 16),
                Text(nombre.isEmpty ? "Tu nombre" : nombre,
                  style: GoogleFonts.fredoka(fontSize: 24, fontWeight: FontWeight.w700, color: _morado),
                ),

                SizedBox(height: 2),
                Text(correo,
                  style: GoogleFonts.poppins(fontSize: 13, fontWeight: FontWeight.w500, color: _moradoClaro),
                ),

                SizedBox(height: 100),
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Navigator.push(
                        context, MaterialPageRoute(builder: (_) => CerrarSesionPage()),
                      );
                    },
                    icon: Icon(Icons.logout_rounded, color: Colors.white),
                    label: Text("Cerrar sesión",
                      style: GoogleFonts.poppins(fontSize: 15, fontWeight: FontWeight.w600, color: Colors.white),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _acento,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(26)),
                    ),
                  ),
                ),
              ],
            ),
          )
      ),

      bottomNavigationBar: BarraNavegacion(indice: 3),

    );
  }
}
