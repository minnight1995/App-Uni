import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/barras/barra_navegacion.dart';
import 'package:unibuddy/cartas/carta_proxtareas.dart';
import 'package:unibuddy/materia/agregar_tarea.dart';
import 'package:unibuddy/utilidades/materias.dart';
import 'package:unibuddy/widgets/widget_materia.dart';
import 'package:unibuddy/api.dart';

class TareasPage extends StatefulWidget {
  final int materiaId;
  final List<Map<String, dynamic>> tareas;

  const TareasPage({
    super.key,
    required this.tareas,
    required this.materiaId,
  });

  @override
  State<TareasPage> createState() => _TareasPageState();
}

class _TareasPageState extends State<TareasPage> {
  static const morado = Color(0xFF4A2FBD);
  int _seccion = 0;

  List<Map<String, dynamic>> _filtrar(bool completadas) {
    final lista = widget.tareas
        .where((t) => (t["completada"] == true) == completadas)
        .toList()
      ..sort((a, b) =>
          (a["fecha"] as DateTime).compareTo(b["fecha"] as DateTime));
    return lista;
  }
  Future<void> _agregar() async {
    final nueva = await Navigator.push<Map<String, dynamic>>(
      context,
      MaterialPageRoute(builder: (_) => const AgregarTarea()),
    );
    if (nueva == null) return;

    final token = await leerToken();
    if (token == null) return;

    final r = await crearTarea(
      token: token,
      materiaId: widget.materiaId,
      titulo: nueva["titulo"],
      fecha: nueva["fecha"],
      prioridad: nueva["prioridad"],
    );
    if (!mounted) return;

    if (r.containsKey("error")) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(r["error"])),
      );
      return;
    }
    setState(() => widget.tareas.add(r));
  }

  @override
  Widget build(BuildContext context) {
    final pendientes = _filtrar(false);
    final completadas = _filtrar(true);
    final visibles = _seccion == 0 ? pendientes : completadas;
    
    return Scaffold(
      backgroundColor: Color(0xFFF5EFFB),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
        foregroundColor: Color(0xFF35147D),
        title: Text("Tareas",
          style: GoogleFonts.fredoka(fontSize: 24, fontWeight: FontWeight.w700, color: Color(0xFF35147D),
          ),
        ),
      ),
      body: Padding(
        padding: EdgeInsetsGeometry.fromLTRB(20, 8, 20, 0),
        child: Column(
          children: [
            WidgetMateria(
                opciones: ["Pendientes (${pendientes.length})", "Completadas (${completadas.length})"],
                indice: _seccion,
                onCambio: (i) => setState (() => _seccion = i),
            ),

            SizedBox(height: 16),
            Expanded(
                child: visibles.isEmpty
                    ? Center(
                  child: Text(_seccion == 0
                        ? "No tienes tareas pendientes."
                        : "Aún no has completado tareas.",
                    style: GoogleFonts.poppins(fontSize: 13, color: Color(0xFF6B6BBF)),
                  ),
                )
                    : ListView.separated(
                  padding: EdgeInsets.only(bottom: 90),
                  itemCount: visibles.length,
                  separatorBuilder: (_, __) => SizedBox(height: 12),
                  itemBuilder: (context, i) {
                    final t = visibles[i];
                    return CartaProxtareas(
                      titulo: t["titulo"],
                      subtitulo: formatearfecha(t["fecha"]),
                      color: colorprioridad(t["prioridad"]),
                      prioridad: t["prioridad"],
                      completada: t["completada"] == true,
                      onCheck: () => completartarea(t, (){
                        if (mounted) setState(() {});
                      }),
                    );
                    },
                ),
            ),
          ],
        ),
      ),

      floatingActionButton: FloatingActionButton(
        backgroundColor: morado,
        foregroundColor: Colors.white,
        shape: CircleBorder(),
        onPressed: _agregar,
        child: Icon(Icons.add, size: 30),
      ),

      bottomNavigationBar: const BarraNavegacion(indice: 1),
    );
  }
}
