import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/accesos/pomodoro_page.dart';
import 'package:unibuddy/barras/barra_navegacion.dart';
import 'package:unibuddy/cartas/carta_acceso.dart';
import 'package:unibuddy/cartas/carta_proxclase.dart';
import 'package:unibuddy/cartas/carta_proxtareas.dart';
import 'package:unibuddy/api.dart';
import 'package:unibuddy/pages/agenda_page.dart';
import 'package:unibuddy/widgets/widget_personaje.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String nombre = "";
  int? genero;
  double progresoSemanal = 0.0;
  Map<String, dynamic>? _proxClase;
  bool _clasesCargadas = false;
  bool _errorClases = false;
  List<Map<String, dynamic>> _proxTareas = [];
  bool _tareasCargadas = false;
  static const _diasCortos = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
  static const _morado = Color(0xFF35147D);
  static const _moradoClaro = Color(0xFF6B6BBF);
  static const _acento = Color(0xFF7957EA);
  String _imagen = "assets/images/personaje.png";


  @override
  void initState() {
    super.initState();
    cargarPerfil();
    cargarTareas();
    cargarProxClase();
    cargarPersonaje().then((img) {
      if (mounted) setState(() => _imagen = img);
    });
  }

  Future<void> cargarTareas() async {
    final token = await leerToken();
    if (token == null) return;

    final materias = await listarMaterias(token);
    if (!mounted || materias == null) return;

    final listas = await Future.wait(
      materias.map((m) => listarTareas(token, m['id'])),
    );
    if (!mounted) return;

    final hoy = DateTime.now();
    final lunes = DateTime(hoy.year, hoy.month, hoy.day)
        .subtract(Duration(days: hoy.weekday - 1));
    final proximoLunes = lunes.add(const Duration(days: 7));

    int total = 0;
    int hechas = 0;
    final pendientes = <Map<String, dynamic>>[];

    for (var i = 0; i < materias.length; i++) {
      final tareas = listas[i];
      if (tareas == null) continue;

      for (final t in tareas) {
        final fecha = DateTime.tryParse('${t['fecha']}')?.toLocal();
        if (fecha == null) continue;

        final c = t['completada'];
        final completada = c == true || c == 1 || c == '1';

        if (!fecha.isBefore(lunes) && fecha.isBefore(proximoLunes)) {
          total++;
          if (completada) hechas++;
        }

        if (!completada) {
          pendientes.add({
            'titulo': '${t['titulo']}',
            'fecha': fecha,
            'prioridad': t['prioridad'],
            'materia': '${materias[i]['nombre']}',
            'color': Color((materias[i]['color'] as num).toInt()),
          });
        }
      }
    }

    pendientes.sort(
            (a, b) => (a['fecha'] as DateTime).compareTo(b['fecha'] as DateTime));

    setState(() {
      progresoSemanal = total == 0 ? 0.0 : hechas / total;
      _proxTareas = pendientes.take(3).toList();
      _tareasCargadas = true;
    });
  }

  Future<void> cargarPerfil() async {
    final token = await leerToken();
    if (token == null) return;

    final datos = await obtenerPerfil(token);
    if (!mounted) return;

    if (datos['error'] == null) {
      final completo = (datos['nombre'] ?? '').toString().trim();
      setState(() {
        nombre = completo.isEmpty ? '' : completo.split(' ').first;
        genero = int.tryParse("${datos['genero'] ?? ''}");
      });
    }
  }

  String _hora12(String hhmm) {
    final p = hhmm.split(':');
    final h = int.tryParse(p[0]) ?? 0;
    final m = p.length > 1 ? p[1].padLeft(2, '0') : '00';
    final h12 = h % 12 == 0 ? 12 : h % 12;
    return '$h12:$m ${h < 12 ? 'AM' : 'PM'}';
  }

  int _minutos(String hhmm) {
    final p = hhmm.split(':');
    return (int.tryParse(p[0]) ?? 0) * 60 +
        (p.length > 1 ? int.tryParse(p[1]) ?? 0 : 0);
  }

  Future<void> cargarProxClase() async {
    final token = await leerToken();
    if (token == null) return;

    final r = await Future.wait([listarClases(token), listarMaterias(token)]);
    if (!mounted) return;

    final clases = r[0];
    final materias = r[1];
    if (clases == null || materias == null) {
      setState(() {
        _clasesCargadas = true;
        _errorClases = true;
      });
      return;
    }

    final ahora = DateTime.now();
    final minAhora = ahora.hour * 60 + ahora.minute;

    Map<String, dynamic>? mejorClase;
    Map<String, dynamic>? mejorMateria;
    int mejorDesfase = 0;
    int mejorMin = 0;

    for (final c in clases) {
      final dia = int.tryParse('${c['dia']}') ?? 0;
      if (dia < 1 || dia > 7) continue;

      Map<String, dynamic>? materia;
      for (final m in materias) {
        if (m['id'] == c['materia_id']) {
          materia = m;
          break;
        }
      }
      if (materia == null) continue;

      final inicio = '${c['inicio']}';
      final min = _minutos(inicio);

      var desfase = (dia - ahora.weekday + 7) % 7;
      if (desfase == 0 && min <= minAhora) desfase = 7;

      final esMejor = mejorClase == null ||
          desfase < mejorDesfase ||
          (desfase == mejorDesfase && min < mejorMin);
      if (esMejor) {
        mejorClase = c;
        mejorMateria = materia;
        mejorDesfase = desfase;
        mejorMin = min;
      }
    }

    Map<String, dynamic>? resultado;
    if (mejorClase != null && mejorMateria != null) {
      final dia = int.parse('${mejorClase['dia']}');
      var hora = _hora12('${mejorClase['inicio']}');
      if (mejorDesfase == 1) {
        hora = 'Mañana · $hora';
      } else if (mejorDesfase > 1) {
        hora = '${_diasCortos[dia - 1]} · $hora';
      }
      resultado = {
        'hora': hora,
        'materia': '${mejorMateria['nombre']}',
        'color': Color((mejorMateria['color'] as num).toInt()),
      };
    }

    setState(() {
      _proxClase = resultado;
      _clasesCargadas = true;
      _errorClases = false;
    });
  }

  Widget _tarjetaMensaje(String texto) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: _acento.withOpacity(0.15),
            blurRadius: 14,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Text(
        texto,
        textAlign: TextAlign.center,
        style: GoogleFonts.poppins(
            fontSize: 13, fontWeight: FontWeight.w500, color: _moradoClaro),
      ),
    );
  }

  Widget _proximasTareas() {
    if (!_tareasCargadas) return const SizedBox(height: 52);

    if (_proxTareas.isEmpty) {
      return _tarjetaMensaje("No tienes tareas pendientes 🎉");
    }

    return Column(
      children: [
        for (final t in _proxTareas)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: CartaProxtareas(
              titulo: t['titulo'],
              subtitulo: t['materia'], // AJUSTA según los parámetros de tu carta
              fecha: t['fecha'], // AJUSTA
              prioridad: t['prioridad'], // AJUSTA
              color: t['color'],
            ),
          ),
      ],
    );
  }

  Widget _proximaClase() {
    if (!_clasesCargadas) return const SizedBox(height: 52);

    final p = _proxClase;
    if (p != null) {
      return CartaProxclase(
        hora: p['hora'],
        materia: p['materia'],
        color: p['color'],
      );
    }

    return _tarjetaMensaje(_errorClases
        ? "No se pudo cargar tu horario"
        : "Aún no tienes clases registradas");
  }

  Widget _encabezado(String titulo, {VoidCallback? onVerTodas}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          titulo,
          style: GoogleFonts.fredoka(fontSize: 18, fontWeight: FontWeight.w700, color: _morado),
        ),
        if (onVerTodas != null)
          GestureDetector(
            onTap: onVerTodas,
            behavior: HitTestBehavior.opaque,
            child: Row(
              children: [
                Text(
                  "Ver todas",
                  style: GoogleFonts.poppins(fontSize: 12, fontWeight: FontWeight.w500, color: _moradoClaro),
                ),

                 SizedBox(width: 2),
                 Icon(Icons.chevron_right, color: Color(0xFF5245AE), size: 16),
              ],
            ),
          ),
      ],
    );
  }

  Widget _mascotaConProgreso() {
    const alturaMascota = 260.0;
    const solape = 70.0;

    return Stack(
      clipBehavior: Clip.none,
      children: [
        SizedBox(
          width: double.infinity,
          height: alturaMascota,
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Align(
                alignment: Alignment.topCenter,
                child: Image.asset(_imagen, height: alturaMascota),
              ),
              Positioned(
                top: 20,
                right: 0,
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: _acento.withOpacity(0.15),
                        blurRadius: 10,
                        offset: Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Text("¡Tú puedes!",
                    style: GoogleFonts.poppins(fontSize: 12, fontWeight: FontWeight.w600, color: _morado),
                  ),
                ),
              ),
            ],
          ),
        ),

        Padding(
          padding: EdgeInsets.only(top: alturaMascota - solape),
          child: _progresoSemanal(),
        ),
      ],
    );
  }

  Widget _progresoSemanal() {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: _acento.withOpacity(0.12),
            blurRadius: 14,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("Tu progreso semanal",
                style: GoogleFonts.fredoka(fontSize: 16, fontWeight: FontWeight.w700, color: _morado),
              ),
              Text("${(progresoSemanal * 100).round()}%",
                style: GoogleFonts.fredoka(fontSize: 18, fontWeight: FontWeight.w700, color: _morado),
              ),
            ],
          ),

          SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: LinearProgressIndicator(
              value: progresoSemanal,
              minHeight: 10,
              backgroundColor: Color(0xFFE6DCF7),
              valueColor: AlwaysStoppedAnimation<Color>(_acento),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5EFFB),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(24, 24, 24, 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(nombre.isEmpty ? "¡Hola!💜" : "¡Hola, $nombre!💜",
                          style: GoogleFonts.fredoka(fontSize: 24, fontWeight: FontWeight.w800, color: _morado),
                        ),

                        SizedBox(height: 2),
                        Text("¿Lista para lograr tus metas?",
                          style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w500, color: _moradoClaro),
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              SizedBox(height: 8),
              _mascotaConProgreso(),

              SizedBox(height: 20),
              _encabezado("Próximas tareas"),

              SizedBox(height: 12),
              _proximasTareas(),

              SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: CartaAcceso(
                      icono: Icons.timer_outlined,
                      texto: "Pomodoro",
                      onTap: () {
                        Navigator.push(
                          context, MaterialPageRoute(builder: (_) => PomodoroPage()),
                        );
                      },
                    ),
                  ),

                  SizedBox(width: 8),
                  Expanded(
                    child: CartaAcceso(
                      icono: Icons.calendar_month_outlined,
                      texto: "Agenda",
                      onTap: () {
                        Navigator.push(
                          context, MaterialPageRoute(builder: (_) => AgendaPage()),
                        );
                      },
                    ),
                  ),
                ],
              ),

              SizedBox(height: 20),
              _encabezado(
                "Próximas clases",
                onVerTodas: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => AgendaPage()),
                  );
                },
              ),

              SizedBox(height: 12),
              _proximaClase(),
            ],
          ),
        ),
      ),

      bottomNavigationBar: BarraNavegacion(indice: 0),
    );
  }
}