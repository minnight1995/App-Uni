import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// Emulador de Android: 10.0.2.2
// Celular real: la IP de tu computador (se ve con "ipconfig")
const String baseUrl = 'https://unibuddy-api-skwe.onrender.com';

// Si algo falla, devuelve un mapa con la clave 'error'
Future<Map<String, dynamic>> _post(
    String ruta,
    Map<String, dynamic> cuerpo, {
      String? token,
    }) async {
  try {
    final r = await http.post(
      Uri.parse('$baseUrl$ruta'),
      headers: {
        'Content-Type': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      },
      body: jsonEncode(cuerpo),
    ).timeout(const Duration(seconds: 60));
    final datos = jsonDecode(r.body) as Map<String, dynamic>;
    if (r.statusCode >= 200 && r.statusCode < 300) return datos;
    return {'error': datos['error'] ?? 'Error del servidor'};
  } catch (e) {
    print('Error de conexión: $e');
    return {'error': 'No se pudo conectar con el servidor'};
  }

}

Future<Map<String, dynamic>> registrarUsuario(
    String nombre, String correo, String password) =>
    _post('/registro', {
      'nombre_completo': nombre,
      'correo': correo,
      'password': password,
    });

Future<Map<String, dynamic>?> iniciarSesion(
    String correo, String password, bool recordarme) async {
  final r = await http
      .post(
    Uri.parse('$baseUrl/login'),
    headers: {'Content-Type': 'application/json'},
    body: jsonEncode({
      'correo': correo,
      'password': password,
      'recordarme': recordarme,
    }),
  )
      .timeout(const Duration(seconds: 60)); // por si Render está dormido

  if (r.statusCode == 200) return jsonDecode(r.body);
  if (r.statusCode == 401) return null; // credenciales incorrectas
  throw Exception('Error del servidor');
}
Future<Map<String, dynamic>> guardarPerfil({
  required String token,
  required String nombre,
  required String carrera,
  required int? semestre,
  required String universidad,
  required int? genero,
}) =>
    _post(
      '/perfil',
      {
        'nombre': nombre,
        'carrera': carrera,
        'semestre': semestre,
        'universidad': universidad,
        'genero': genero,
      },
      token: token,
    );

Future<Map<String, dynamic>> obtenerPerfil(String token) async {
  try {
    final r = await http.get(
      Uri.parse('$baseUrl/perfil'),
      headers: {'Authorization': 'Bearer $token'},
    ).timeout(const Duration(seconds: 60));
    final datos = jsonDecode(r.body) as Map<String, dynamic>;
    if (r.statusCode == 200) return datos;
    return {'error': datos['error'] ?? 'Error del servidor'};
  } catch (e) {
    print('Error al leer perfil: $e');
    return {'error': 'No se pudo conectar con el servidor'};
  }
}

// Actualiza nombre y correo del usuario
Future<Map<String, dynamic>> actualizarPerfil(
    String token, String nombre, String correo) async {
  try {
    final r = await http
        .put(
      Uri.parse('$baseUrl/perfil/datos'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({'nombre': nombre, 'correo': correo}),
    )
        .timeout(const Duration(seconds: 60));
    final datos = jsonDecode(r.body) as Map<String, dynamic>;
    if (r.statusCode == 200) return datos;
    return {'error': datos['error'] ?? 'Error del servidor'};
  } catch (e) {
    return {'error': 'No se pudo conectar con el servidor'};
  }
}

String fechaHoy() {
  final n = DateTime.now();
  final mes = n.month.toString().padLeft(2, '0');
  final dia = n.day.toString().padLeft(2, '0');
  return '${n.year}-$mes-$dia';
}

// Registra actividad de hoy; el Pomodoro pasará los puntos ganados
Future<Map<String, dynamic>> registrarActividad(String token,
    {int puntos = 0}) =>
    _post('/actividad', {'fecha': fechaHoy(), 'puntos': puntos}, token: token);

// Solo lee racha y puntos
Future<Map<String, dynamic>> obtenerResumen(String token) async {
  try {
    final r = await http.get(
      Uri.parse('$baseUrl/resumen?hoy=${fechaHoy()}'),
      headers: {'Authorization': 'Bearer $token'},
    ).timeout(const Duration(seconds: 60));
    final datos = jsonDecode(r.body) as Map<String, dynamic>;
    if (r.statusCode == 200) return datos;
    return {'error': datos['error'] ?? 'Error del servidor'};
  } catch (e) {
    return {'error': 'No se pudo conectar con el servidor'};
  }
}
// ---------- Sesión guardada en el celular (Recuérdame) ----------
Future<void> guardarToken(String token) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setString('token', token);
}

Future<String?> leerToken() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getString('token');
}

Future<void> cerrarSesion() async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.remove('token');
}

// ---------- Materias ----------
// Devuelve la lista, o null si algo falló
Future<List<Map<String, dynamic>>?> listarMaterias(String token) async {
  try {
    final r = await http.get(
      Uri.parse('$baseUrl/materias'),
      headers: {'Authorization': 'Bearer $token'},
    ).timeout(const Duration(seconds: 60));
    if (r.statusCode != 200) return null;
    return List<Map<String, dynamic>>.from(jsonDecode(r.body));
  } catch (e) {
    print('Error al leer materias: $e');
    return null;
  }
}

// Devuelve la materia guardada (con su id) o un mapa con 'error'
Future<Map<String, dynamic>> crearMateria({
  required String token,
  required String nombre,
  required String profesor,
  required int icono,
  required int color,
}) =>
    _post(
      '/materias',
      {
        'nombre': nombre,
        'profesor': profesor,
        'icono': icono,
        'color': color,
      },
      token: token,
    );
Future<Map<String, dynamic>> actualizarMateria(String token, int id,
    String nombre, String profesor, int icono, int color) async {
  try {
    final r = await http
        .put(
      Uri.parse('$baseUrl/materias/$id'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({
        'nombre': nombre,
        'profesor': profesor,
        'icono': icono,
        'color': color,
      }),
    )
        .timeout(const Duration(seconds: 60));
    final datos = jsonDecode(r.body) as Map<String, dynamic>;
    if (r.statusCode == 200) return datos;
    return {'error': datos['error'] ?? 'Error del servidor'};
  } catch (e) {
    return {'error': 'No se pudo conectar con el servidor'};
  }
}
Future<Map<String, dynamic>> guardarDescripcion(
    String token, int id, String descripcion) async {
  try {
    final r = await http
        .put(
      Uri.parse('$baseUrl/materias/$id/descripcion'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({'descripcion': descripcion}),
    )
        .timeout(const Duration(seconds: 60));
    final datos = jsonDecode(r.body) as Map<String, dynamic>;
    if (r.statusCode == 200) return datos;
    return {'error': datos['error'] ?? 'Error del servidor'};
  } catch (e) {
    return {'error': 'No se pudo conectar con el servidor'};
  }
}

// ---------- Tareas ----------
String _fechaSql(DateTime f) {
  String d2(int n) => n.toString().padLeft(2, '0');
  return '${f.year}-${d2(f.month)}-${d2(f.day)} ${d2(f.hour)}:${d2(f.minute)}:00';
}

Future<List<Map<String, dynamic>>?> listarTareas(
    String token, int materiaId) async {
  try {
    final r = await http.get(
      Uri.parse('$baseUrl/materias/$materiaId/tareas'),
      headers: {'Authorization': 'Bearer $token'},
    ).timeout(const Duration(seconds: 60));
    if (r.statusCode != 200) return null;
    final lista = List<Map<String, dynamic>>.from(jsonDecode(r.body));
    return lista.map((t) => {...t, 'fecha': DateTime.parse(t['fecha'])}).toList();
  } catch (e) {
    print('Error al leer tareas: $e');
    return null;
  }
}

Future<Map<String, dynamic>> crearTarea({
  required String token,
  required int materiaId,
  required String titulo,
  required DateTime fecha,
  required String prioridad,
}) async {
  final r = await _post(
    '/materias/$materiaId/tareas',
    {'titulo': titulo, 'fecha': _fechaSql(fecha), 'prioridad': prioridad},
    token: token,
  );
  if (r.containsKey('error')) return r;
  r['fecha'] = DateTime.parse(r['fecha']);
  return r;
}

Future<Map<String, dynamic>> marcarTarea(
    String token, int id, bool completada) async {
  try {
    final r = await http
        .put(
      Uri.parse('$baseUrl/tareas/$id/completada'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({'completada': completada}),
    )
        .timeout(const Duration(seconds: 60));
    final datos = jsonDecode(r.body) as Map<String, dynamic>;
    if (r.statusCode == 200) return datos;
    return {'error': datos['error'] ?? 'Error del servidor'};
  } catch (e) {
    return {'error': 'No se pudo conectar con el servidor'};
  }
}

// ---------- Apuntes ----------
Future<List<Map<String, dynamic>>?> listarApuntes(
    String token, int materiaId) async {
  try {
    final r = await http.get(
      Uri.parse('$baseUrl/materias/$materiaId/apuntes'),
      headers: {'Authorization': 'Bearer $token'},
    ).timeout(const Duration(seconds: 60));
    if (r.statusCode != 200) return null;
    final lista = List<Map<String, dynamic>>.from(jsonDecode(r.body));
    return lista.map((a) => {...a, 'fecha': DateTime.parse(a['fecha'])}).toList();
  } catch (e) {
    print('Error al leer apuntes: $e');
    return null;
  }
}

// Devuelve el apunte guardado (con su id) o un mapa con 'error'
Future<Map<String, dynamic>> crearApunte({
  required String token,
  required int materiaId,
  required String titulo,
  required String contenido,
  required DateTime fecha,
}) async {
  final r = await _post(
    '/materias/$materiaId/apuntes',
    {'titulo': titulo, 'contenido': contenido, 'fecha': _fechaSql(fecha)},
    token: token,
  );
  if (r.containsKey('error')) return r;
  r['fecha'] = DateTime.parse(r['fecha']);
  return r;
}

Future<Map<String, dynamic>> actualizarApunte(String token, int id,
    String titulo, String contenido, DateTime fecha) async {
  try {
    final r = await http
        .put(
      Uri.parse('$baseUrl/apuntes/$id'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({
        'titulo': titulo,
        'contenido': contenido,
        'fecha': _fechaSql(fecha),
      }),
    )
        .timeout(const Duration(seconds: 60));
    final datos = jsonDecode(r.body) as Map<String, dynamic>;
    if (r.statusCode == 200) return datos;
    return {'error': datos['error'] ?? 'Error del servidor'};
  } catch (e) {
    return {'error': 'No se pudo conectar con el servidor'};
  }
}

Future<Map<String, dynamic>> borrarApunte(String token, int id) async {
  try {
    final r = await http.delete(
      Uri.parse('$baseUrl/apuntes/$id'),
      headers: {'Authorization': 'Bearer $token'},
    ).timeout(const Duration(seconds: 60));
    final datos = jsonDecode(r.body) as Map<String, dynamic>;
    if (r.statusCode == 200) return datos;
    return {'error': datos['error'] ?? 'Error del servidor'};
  } catch (e) {
    return {'error': 'No se pudo conectar con el servidor'};
  }
}

// ---------- Horario de clases ----------
Future<List<Map<String, dynamic>>?> listarClases(String token) async {
  try {
    final r = await http.get(
      Uri.parse('$baseUrl/clases'),
      headers: {'Authorization': 'Bearer $token'},
    ).timeout(const Duration(seconds: 60));
    if (r.statusCode != 200) return null;
    return List<Map<String, dynamic>>.from(jsonDecode(r.body));
  } catch (e) {
    print('Error al leer clases: $e');
    return null;
  }
}

// Devuelve {'clases': [...]} o un mapa con 'error'
Future<Map<String, dynamic>> crearClases({
  required String token,
  required int materiaId,
  required List<int> dias,
  required String inicio,
  required String fin,
  required String salon,
}) =>
    _post(
      '/clases',
      {
        'materia_id': materiaId,
        'dias': dias,
        'inicio': inicio,
        'fin': fin,
        'salon': salon,
      },
      token: token,
    );

Future<Map<String, dynamic>> borrarClase(String token, int id) async {
  try {
    final r = await http.delete(
      Uri.parse('$baseUrl/clases/$id'),
      headers: {'Authorization': 'Bearer $token'},
    ).timeout(const Duration(seconds: 60));
    final datos = jsonDecode(r.body) as Map<String, dynamic>;
    if (r.statusCode == 200) return datos;
    return {'error': datos['error'] ?? 'Error del servidor'};
  } catch (e) {
    return {'error': 'No se pudo conectar con el servidor'};
  }
}

// ---------- Eventos de la agenda ----------
String _soloFecha(DateTime d) {
  String d2(int n) => n.toString().padLeft(2, '0');
  return '${d.year}-${d2(d.month)}-${d2(d.day)}';
}

// Convierte las fechas de texto a DateTime
Map<String, dynamic> _eventoDeApi(Map<String, dynamic> e) => {
  ...e,
  'inicio': DateTime.parse(e['inicio']),
  'fin': e['fin'] == null ? null : DateTime.parse(e['fin']),
  'lugar': e['lugar'] ?? '',
  'descripcion': e['descripcion'] ?? '',
};

Map<String, dynamic> _cuerpoEvento({
  required String titulo,
  required int categoria,
  required DateTime inicio,
  DateTime? fin,
  required String lugar,
  required String descripcion,
}) =>
    {
      'titulo': titulo,
      'categoria': categoria,
      'inicio': _fechaSql(inicio),
      'fin': fin == null ? null : _fechaSql(fin),
      'lugar': lugar,
      'descripcion': descripcion,
    };

// Sin fechas trae todos; con desde y hasta, solo ese rango
Future<List<Map<String, dynamic>>?> listarEventos(String token,
    {DateTime? desde, DateTime? hasta}) async {
  try {
    final params = <String, String>{
      if (desde != null) 'desde': _soloFecha(desde),
      if (hasta != null) 'hasta': _soloFecha(hasta),
    };
    final uri = Uri.parse('$baseUrl/eventos').replace(
      queryParameters: params.isEmpty ? null : params,
    );
    final r = await http
        .get(uri, headers: {'Authorization': 'Bearer $token'})
        .timeout(const Duration(seconds: 60));
    if (r.statusCode != 200) return null;
    final lista = List<Map<String, dynamic>>.from(jsonDecode(r.body));
    return lista.map(_eventoDeApi).toList();
  } catch (e) {
    print('Error al leer eventos: $e');
    return null;
  }
}

// Devuelve el evento guardado (con su id) o un mapa con 'error'
Future<Map<String, dynamic>> crearEvento({
  required String token,
  required String titulo,
  required int categoria,
  required DateTime inicio,
  DateTime? fin,
  String lugar = '',
  String descripcion = '',
}) async {
  final r = await _post(
    '/eventos',
    _cuerpoEvento(
      titulo: titulo,
      categoria: categoria,
      inicio: inicio,
      fin: fin,
      lugar: lugar,
      descripcion: descripcion,
    ),
    token: token,
  );
  if (r.containsKey('error')) return r;
  return _eventoDeApi(r);
}

// Devuelve el evento actualizado o un mapa con 'error'
Future<Map<String, dynamic>> actualizarEvento({
  required String token,
  required int id,
  required String titulo,
  required int categoria,
  required DateTime inicio,
  DateTime? fin,
  String lugar = '',
  String descripcion = '',
}) async {
  try {
    final r = await http
        .put(
      Uri.parse('$baseUrl/eventos/$id'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode(_cuerpoEvento(
        titulo: titulo,
        categoria: categoria,
        inicio: inicio,
        fin: fin,
        lugar: lugar,
        descripcion: descripcion,
      )),
    )
        .timeout(const Duration(seconds: 60));
    final datos = jsonDecode(r.body) as Map<String, dynamic>;
    if (r.statusCode == 200) return _eventoDeApi(datos);
    return {'error': datos['error'] ?? 'Error del servidor'};
  } catch (e) {
    return {'error': 'No se pudo conectar con el servidor'};
  }
}

Future<Map<String, dynamic>> borrarEvento(String token, int id) async {
  try {
    final r = await http.delete(
      Uri.parse('$baseUrl/eventos/$id'),
      headers: {'Authorization': 'Bearer $token'},
    ).timeout(const Duration(seconds: 60));
    final datos = jsonDecode(r.body) as Map<String, dynamic>;
    if (r.statusCode == 200) return datos;
    return {'error': datos['error'] ?? 'Error del servidor'};
  } catch (e) {
    return {'error': 'No se pudo conectar con el servidor'};
  }
}

Future<Map<String, dynamic>> actualizarClase({
  required String token,
  required int id,
  required int materiaId,
  required int dia,
  required String inicio,
  required String fin,
  String salon = '',
}) async {
  try {
    final r = await http
        .put(
      Uri.parse('$baseUrl/clases/$id'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({
        'materia_id': materiaId,
        'dia': dia,
        'inicio': inicio,
        'fin': fin,
        'salon': salon,
      }),
    )
        .timeout(const Duration(seconds: 60));
    final datos = jsonDecode(r.body) as Map<String, dynamic>;
    if (r.statusCode == 200) return datos;
    return {'error': datos['error'] ?? 'Error del servidor'};
  } catch (e) {
    return {'error': 'No se pudo conectar con el servidor'};
  }
}