import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CartaDato extends StatelessWidget {
  final IconData icono;
  final Color color;
  final String valor;
  final String etiqueta;

  const CartaDato({
    super.key,
    required this.icono,
    required this.color,
    required this.valor,
    required this.etiqueta
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: Color(0xFF7957EA).withOpacity(0.15),
            blurRadius: 14,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          Icon(icono, color: color, size: 38),
          
          SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(valor, style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w700, color: Color(0xFF35147D))),
              Text(etiqueta, style: GoogleFonts.poppins(fontSize: 13, fontWeight: FontWeight.w400, color: Color(0xFF5245AE))),
            ],
          )
        ],
      ),
    );
  }
}
