import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CartaMateria extends StatelessWidget {
  final String materia;
  final String profesor;
  final IconData icono;
  final Color color;
  final double progreso;
  final VoidCallback? onTap;

  const CartaMateria({
    super.key,
    required this.materia,
    required this.profesor,
    required this.icono,
    required this.color,
    this.progreso = 0.0,
    this.onTap
  });

  @override
  Widget build(BuildContext context) {
    final porcentaje = (progreso * 100).round();

    return Material(
      color: Colors.white,
      elevation: 3,
      shadowColor: Colors.black26,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Padding(
            padding: EdgeInsets.all(24),
          child: Row(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(icono, color: Colors.white, size: 30),
              ),

              SizedBox(width: 14),
              Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                              child:  Text(materia,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: GoogleFonts.fredoka(fontSize: 16, fontWeight: FontWeight.w600, color: Color(0xFF35147D)),
                              ),
                          ),
                          SizedBox(height: 8),
                          Text("$porcentaje%",
                            style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w600, color: Color(0xFF35147D)),
                          ),
                        ],

                      ),
                      
                      Text(profesor,
                      style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w500, color: Color(0xFF6B6BBF)),
                      ),

                      SizedBox(height: 8),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: LinearProgressIndicator(
                          value: progreso,
                          minHeight: 8,
                          backgroundColor: Colors.grey.shade200,
                          valueColor: AlwaysStoppedAnimation<Color>(color)
                        ),
                      ),
                    ],
                  ),
              ),
              
              SizedBox(width: 8),
              Icon(Icons.chevron_right, color: Color(0xFF4A2FBD)),
            ],
          ),
        ),

      ),
    );
  }
}
