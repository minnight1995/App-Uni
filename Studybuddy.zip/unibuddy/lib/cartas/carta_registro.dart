import 'package:flutter/material.dart';

class CartaRegistro extends StatefulWidget {
  final IconData icono;
  final String nombre;
  final TextEditingController control;
  final bool contrasena;

  const CartaRegistro({
    super.key,
    required this.icono,
    required this.nombre,
    required this.control,
    this.contrasena = false,
  });
  @override
  State<CartaRegistro> createState() => _CartaRegistroState();
}

class _CartaRegistroState extends State<CartaRegistro> {
  bool ocultar = true;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
            color: Color(0xFF7B5CD6).withOpacity(0.15),
            blurRadius: 10,
            offset: Offset(0, 4),
          )
        ]
      ),
      child: Row(
        children: [
          Icon(widget.icono, color: Color(0xFF5245AE)),

          SizedBox(width: 12),
          Expanded(
              child: TextField(
                controller: widget.control,
                obscureText: widget.contrasena && ocultar,
                decoration: InputDecoration(
                  hintText: widget.nombre,
                  border: InputBorder.none,
                ),
              ),
          ),
          if (widget.contrasena)
            IconButton(
                onPressed: () => setState(() => ocultar = !ocultar),
                icon: Icon(ocultar ? Icons.visibility_off : Icons.visibility)
            ),
        ],
      ),
    );
  }
}