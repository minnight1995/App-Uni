import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CartaProxclase extends StatelessWidget {
  final String hora;
  final String materia;
  final Color color;
  final VoidCallback? onTap;

  const CartaProxclase({
    super.key,
    required this.hora,
    required this.materia,
    required this.color,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(22),
          boxShadow: [
            BoxShadow(
              color: Color(0xFF7957EA).withOpacity(0.15),
              blurRadius: 14,
              offset: Offset(0, 6),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 12,
              height: 12,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color,
              ),
            ),

            SizedBox(width: 12),
            Text(hora,
              style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w600, color: Color(0xFF5245AE)),
            ),

            SizedBox(width: 16),
            Expanded(
                child: Text(materia,maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w700, color: Color(0xFF35147D)),
                )
            ),
          ],
        ),
      ),
    );
  }
}