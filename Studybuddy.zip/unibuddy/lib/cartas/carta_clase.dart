import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CartaClase extends StatelessWidget {
  final String nombre;
  final String profesor;
  final Color color;
  final String salon;
  final String inicio;
  final String fin;
  final VoidCallback onLongPress;
  final VoidCallback? onTap;



  const CartaClase({
    super.key,
    required this.nombre,
    required this.profesor,
    required this.color,
    required this.salon,
    required this.inicio,
    required this.fin,
    required this.onLongPress,
    this.onTap,
  });

  Widget _pastilla(IconData icono, String texto, Color fondo) {
    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      child: Container(
          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: fondo,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icono, color: Colors.white, size: 14),

              SizedBox(width: 6),
              Text(
                texto,
                style: GoogleFonts.poppins(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.white,
                ),
              ),
            ],
          ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: Color(0xFF7957EA).withOpacity(0.15),
            blurRadius: 14,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(nombre,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.fredoka(fontSize: 17, fontWeight: FontWeight.w700, color: Color(0xFF35147D)),
          ),

          SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              if (salon.isNotEmpty)
                _pastilla(Icons.location_on_rounded, 'Salón: $salon', Color(0xFF35147D)),
              _pastilla(Icons.access_time_filled_rounded, '$inicio - $fin', color),
            ],
          ),
          if(profesor.isNotEmpty) ...[
            SizedBox(height: 12),
            Divider(height: 1),
            SizedBox(height: 10),

            Row(
              children: [
                Icon(Icons.person_outline_rounded, color: Color(0xFF6B6BBF), size: 20),

                SizedBox(width: 8),
                Expanded(
                    child: Text(profesor,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.poppins(fontSize: 13, fontWeight: FontWeight.w500, color: Color(0xFF5245AE),
                      ),
                    )
                ),
              ],
            )
          ]
        ],
      ),
    );
  }
}
