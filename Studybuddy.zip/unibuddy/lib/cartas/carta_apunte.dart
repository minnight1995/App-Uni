import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CartaApunte extends StatelessWidget {
  final String titulo;
  final String fecha;
  final Color fondo;
  final Color acento;
  final VoidCallback onTap;

  const CartaApunte({
    super.key,
    required this.titulo,
    required this.fecha,
    required this.fondo,
    required this.acento,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: fondo,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Padding(
            padding: EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(Icons.description_rounded, color: acento, size: 34),
                  Icon(Icons.chevron_right, color: acento, size: 20),
                ],
              ),

              Spacer(),
              Text(titulo,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.fredoka(fontSize: 16, fontWeight: FontWeight.w600, color: Color(0xFF35147D)),
              ),

              SizedBox(height: 2),
              Text(fecha,
                style: GoogleFonts.poppins(fontSize: 12, fontWeight: FontWeight.w500, color: Color(0xFF5245AE),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
