import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CartaObjetivo extends StatelessWidget {
  final String url;
  final String titulo;
  final bool seleccionado;

  const CartaObjetivo({
    super.key,
    required this.url,
    required this.titulo,
    required this.seleccionado,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        padding: EdgeInsets.all(8),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: Colors.white,
            border: Border.all(
              color: seleccionado ? Color(0xFF7B5CD6) : Colors.transparent,
              width: 9,
            )
        ),

        child: Stack(
          children: [
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundImage: AssetImage(url),
                  ),

                  SizedBox(height: 8),
                  Text(titulo,
                    style: GoogleFonts.poppins(fontSize: 12, fontWeight: FontWeight.w500, color: Color(0xFF35147D)),
                  ),
                ],
              ),
            ),
            if (seleccionado)
              Positioned(
                  child: Icon(Icons.check_circle, color: Color(0xFF5245AE), size: 22),
              ),
          ],
        ),
      ),
    );
  }
}
