import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CartaAcceso extends StatelessWidget {
  final IconData icono;
  final String texto;
  final bool activa;
  final VoidCallback? onTap;

  const CartaAcceso({
    super.key,
    required this.icono,
    required this.texto,
    this.activa = false,
    this.onTap
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 18),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: activa
                ? [Color(0xFF9675E8), Color(0xFF7B5CD6)]
                : [Color(0xFFEDE4FA), Color(0xFFDCCDF5)],
          ),
          boxShadow: [
            BoxShadow(
              color: Color(0xFF7957EA).withOpacity(activa ? 0.40 : 0.15),
              blurRadius: activa ? 14 : 10,
              offset: Offset(0, activa ? 7 : 5),
            ),
          ],
          ),
        
        child: Column(
          children: [
            Icon(icono, size: 36,color: activa ? Colors.white : Color(0xFF7B5CD6)),
            
            SizedBox(height: 8),
            Text(texto,
            style: GoogleFonts.poppins(fontSize: 13, fontWeight: FontWeight.w600, 
                color: activa ? Colors.white : Color(0xFF35147D)),
            )
          ],
        ),
        ),
    );
  }
}
