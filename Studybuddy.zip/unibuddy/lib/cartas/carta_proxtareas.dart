import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/utilidades/materias.dart';

class CartaProxtareas extends StatelessWidget {
  final String titulo;
  final String? subtitulo;
  final DateTime? fecha;
  final Color? color;
  final bool completada;
  final String? prioridad;
  final VoidCallback? onTap;
  final VoidCallback? onCheck;

  const CartaProxtareas({
    super.key,
    required this.titulo,
    this.subtitulo,
    this.fecha,
    this.color,
    this.completada = false,
    this.prioridad,
    this.onTap,
    this.onCheck,
  }): assert(subtitulo != null || fecha != null, "Pasa subtitulo o fecha");

  @override
  Widget build(BuildContext context) {
    final detalle = prioridad != null;
    final tamano = detalle ? 22.0 : 28.0;
    final texto = fecha != null ? formatearfecha(fecha!) : subtitulo!;
    final colorbase = color ?? (detalle ? colorprioridad(prioridad!) : Color(0xFF7B5CD6));
    final coloretiqueta = detalle ? colorprioridad(prioridad!) : colorbase;
    final fondoetiqueta = coloretiqueta.withOpacity(0.18);
    final textoetiqueta = Color.lerp(coloretiqueta, Colors.black, 0.2)!;

    Widget casilla = SizedBox(
      width: tamano,
      height: tamano,
      child: completada
          ?null
          :GestureDetector(
        onTap: onCheck,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(detalle ? 6 : 8),
            border: Border.all(color: colorbase, width: 2.5),
          ),
        ),
      ),
    );

    if (detalle) {
      casilla = Container(
        width: 46,
        height: 46,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: colorbase.withOpacity(0.18),
          borderRadius: BorderRadius.circular(14),
        ),
        child: casilla,
      );
    }

    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(22),
          boxShadow: [
            BoxShadow(
              color: Color(0xFF7957EA).withOpacity(0.15),
              blurRadius: 14,
              offset: Offset(0, 6),
            )
          ]
        ),
        child: Row(
          children: [
            casilla,

            SizedBox(width: 14),
            Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(titulo, maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.poppins(fontSize: 15, fontWeight: FontWeight.w600, color: Color(0xFF35147D),
                        decoration: completada ? TextDecoration.lineThrough : null),
                    ),
                    Text(texto, maxLines: 1,
                    style: GoogleFonts.poppins(fontSize: 13, fontWeight: FontWeight.w500, color: Color(0xFF5245AE)),
                    ),
                  ],
                ),
            ),

            if (detalle)
              Container(
                padding: EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: fondoetiqueta,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Text(prioridad!,
                  style: GoogleFonts.poppins(fontSize: 13, fontWeight: FontWeight.w600, color: textoetiqueta,
                  ),
                ),
              )
            else
              const Icon(Icons.chevron_right, color: Color(0xFF7B5CD6)),
          ],
        ),
      ),
    );
  }
}
