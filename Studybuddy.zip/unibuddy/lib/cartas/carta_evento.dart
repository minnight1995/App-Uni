import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/utilidades/agenda.dart';
import 'package:unibuddy/utilidades/eventos.dart';

class CartaEvento extends StatelessWidget {
  final ItemAgenda item;
  final bool compacta;
  final VoidCallback? onTap;

  const CartaEvento({
    super.key,
    required this.item,
    this.compacta = false,
    this.onTap,
  });

  static const _oscuro = Color(0xFF35147D);
  static const _suave = Color(0xFF5245AE);

  Widget _compacta(CategoriaAgenda categoria) {
    return SizedBox(
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "${horaampm(item.inicio)} - ${categoria.nombre}",
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.poppins(fontSize: 13, fontWeight: FontWeight.w600, color: _oscuro),
          ),

          SizedBox(height: 2),
          Text(
            item.titulo,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w500, color: _suave),
          ),
        ],
      ),
    );
  }

  Widget _normal(CategoriaAgenda categoria) {
    return Row(
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: item.color,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(categoria.icono, color: Colors.white, size: 22),
        ),

        SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                item.titulo,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.fredoka(fontSize: 16, fontWeight: FontWeight.w600, color: _oscuro),
              ),
              Text(
                item.subtitulo,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.poppins(fontSize: 12, fontWeight: FontWeight.w500, color: _suave,
                ),
              ),
            ],
          ),
        ),
        if (onTap != null)
          Icon(Icons.chevron_right, color: _suave, size: 22),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final fondo = Color.alphaBlend(item.color.withOpacity(0.22), Colors.white);
    final categoria = categoriasagenda[item.categoria];

    return Material(
      color: fondo,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Padding(
          padding: EdgeInsets.all(14),
          child: compacta ? _compacta(categoria) : _normal(categoria),
        ),
      ),
    );
  }
}

