import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Cartagenero extends StatelessWidget {
  final String url;
  final String titulo;
  final bool seleccionado;
  final ValueChanged<bool?> onChanged;

  const Cartagenero({
    super.key,
    required this.url,
    required this.titulo,
    required this.seleccionado,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: Colors.white,
        border: Border.all(
          color: seleccionado ? Color(0xFF7B5CD6) : Colors.transparent,
          width: 3,
        )
      ),
      child: Column(
        children: [
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: Image.asset(
                url,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ),
          ),

          SizedBox(height: 8),
          Text(
            titulo,
            style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w600, color: Color(0xFF4A2A6B),
            ),
          ),

          Checkbox(
            value: seleccionado,
            onChanged: onChanged,
            activeColor: Color(0xFF7B5CD6),
            shape: CircleBorder(),
          ),
        ],
      ),
    );
  }
}
