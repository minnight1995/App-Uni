import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/api.dart';
import 'package:unibuddy/widgets/widget_personaje.dart';

enum Fase { estudio, descansoCorto, descansoLargo}

class PomodoroPage extends StatefulWidget {
  const PomodoroPage({super.key});

  @override
  State<PomodoroPage> createState() => _PomodoroPageState();
}

class _PomodoroPageState extends State<PomodoroPage> with WidgetsBindingObserver{
static int mindescansolargo = 15;
static int sesionesporciclo = 4;
final opcionesdescanso = [5, 10, 15];
final opcionesestudio = [15, 25, 45, 60];
int mindescansocorto = 5;
int minestudio = 25;
int get puntosporsesion => (minestudio * 2/5).round().clamp(1, 1000).toInt();
Fase fase = Fase.estudio;
int sesionescompletas = 0;
bool corriendo = false;
DateTime? finEn;
Timer? timer;
late Duration restante;
String _imagen = "assets/images/personaje_buddy.png";


Duration get duracionfase => Duration(
  minutes: fase == Fase.estudio
      ?minestudio
      :fase == Fase.descansoCorto
      ?mindescansocorto
      :mindescansolargo,
);

String get etiquetafase => fase == Fase.estudio
    ?"Tiempo de estudio"
    :fase == Fase.descansoCorto
    ?"Descanso corto"
    :"Descanso largo";

String get textotiempo{
  final seg = (restante.inMilliseconds/1000).ceil();
  final m = (seg~/60).toString().padLeft(2, '0');
  final s = (seg%60).toString().padLeft(2,'0');
  return '$m:$s';
}

double get progreso => 1 - restante.inMilliseconds/duracionfase.inMilliseconds;

@override
void initState(){
  super.initState();
  cargarPersonaje().then((img) {
    if (mounted) setState(() => _imagen = img);
  });
  restante = duracionfase;
  WidgetsBinding.instance.addObserver(this);
}

@override
void dispose(){
  timer?.cancel();
  WidgetsBinding.instance.removeObserver(this);
  super.dispose();
}

@override
void didChangeAppLifecycleState(AppLifecycleState state) {
  if (state == AppLifecycleState.resumed && corriendo) _tick();
}

void iniciar(){
  finEn = DateTime.now().add(restante);
  timer?.cancel();
  timer = Timer.periodic(Duration(milliseconds: 250), (_) => _tick());
  setState(() => corriendo = true);
}

void pausar(){
  timer?.cancel();
  final falta = finEn!.difference(DateTime.now());
  setState(() {
    corriendo = false;
    restante = falta.isNegative ? Duration.zero : falta;
  });
}

void reiniciar(){
  timer?.cancel();
  setState(() {
    corriendo = false;
    restante = duracionfase;
  });
}

void _saltardescanso(){
  timer?.cancel();
  setState(() {
    corriendo = false;
    fase = Fase.estudio;
    restante = duracionfase;
  });
}

void _tick(){
  if(finEn == null) return;
  final falta = finEn!.difference(DateTime.now());
  if(falta <= Duration.zero){
    _terminarfase();
  }else{
    setState(() => restante = falta);
  }
}

void _terminarfase(){
  timer?.cancel();
  final eraestudio = fase == Fase.estudio;
  final puntosganados = puntosporsesion;
  if(eraestudio){
    sesionescompletas++;
    _darpuntos(puntosganados);
  }
  setState(() {
    corriendo = false;
    if(eraestudio){
    fase = sesionescompletas % sesionesporciclo == 0
    ?Fase.descansoLargo
    :Fase.descansoCorto;
    }else{
      fase = Fase.estudio;
    }
    restante = duracionfase;
  });

  _mostrar(eraestudio
      ? '¡Sesión completada! +$puntosganados puntos 🎉'
      : '¡Descanso terminado! A estudiar 💪'
  );
}

Future<void> _darpuntos(int puntos) async{
  final token = await leerToken();
  if(token == null) return;
  await registrarActividad(token, puntos: puntos);
}

void _mostrar(String texto){
  if(!mounted) return;
  ScaffoldMessenger.of(context).showSnackBar(
      SnackBar (content : Text(texto)),
  );
}

void _cambiardescanso(){
  if(corriendo) return;
  final i = opcionesdescanso.indexOf(mindescansocorto);
  setState(() {
    mindescansocorto = opcionesdescanso[(i + 1) % opcionesdescanso.length];
    if(fase == Fase.descansoCorto) restante = duracionfase;
  });
}

void _cambiarestudio(int minutos){
  setState(() {
    minestudio = minutos;
    if(fase == Fase.estudio) restante = duracionfase;
  });
}

Future<void> _otrotiempo() async{
  final control = TextEditingController();
  final minutos = await showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text("¿Cuántos minutos?"),
        content: TextField(
          controller: control,
          keyboardType: TextInputType.number,
          autofocus: true,
          decoration: InputDecoration(hintText: "Entre 1 y 100"),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), 
              child: Text("Cancelar"),
          ),
          TextButton(
              onPressed: () => Navigator.pop(ctx, int.tryParse(control.text)),
              child: Text("Aceptar"),
          ),
        ],
      ),
  );

  if(minutos != null && minutos >= 1 && minutos <= 100){
    _cambiarestudio(minutos);
  }
}

Widget _chip(String texto, bool activo, VoidCallback? onTap) {
  return ChoiceChip(
    label: Text(texto),
    selected: activo,
    showCheckmark: false,
    onSelected: onTap == null ? null : (_) => onTap(),
    selectedColor: Color(0xFF7B5CD6),
    backgroundColor: Colors.white,
    labelStyle: GoogleFonts.poppins(
      fontSize: 13,
      fontWeight: FontWeight.w600,
      color: activo ? Colors.white : Color(0xFF35147D),
    ),
  );
}

  @override
  Widget build(BuildContext context) {
  final enestudio = fase == Fase.estudio;
  final empezando = restante != duracionfase;
  final bloqueado = corriendo || empezando;
  final espersonalizado = !opcionesestudio.contains(minestudio);
  final llenos = fase == Fase.descansoLargo
  ?sesionesporciclo
      :sesionescompletas % sesionesporciclo;

    return Scaffold(
      backgroundColor: Color(0xFFF5EFFB),
      body: SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.all(24),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                        onPressed: () => Navigator.pop(context),
                        icon: Icon(Icons.arrow_back, color: Color(0xFF35147D)),
                    ),
                  ],
                ),

                Image.asset(_imagen, height: 150),

                SizedBox(height: 12),
                SizedBox(
                  width: 250,
                  height: 250,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: 230,
                        height: 230,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: Color(0xFF7957EA).withOpacity(0.18),
                              blurRadius: 20,
                              offset: Offset(0, 8),
                            ),
                          ]
                        ),
                      ),
                      
                      SizedBox(
                        width: 250,
                        height: 250,
                        child: CircularProgressIndicator(
                          value: progreso,
                          strokeWidth: 10,
                          strokeCap: StrokeCap.round,
                          backgroundColor: Color(0xFFE4D9F7),
                          color: enestudio ? Color(0xFF7B5CD6) : Colors.teal,
                        ),
                      ),

                      Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(textotiempo,
                          style: GoogleFonts.poppins(fontSize: 52, fontWeight: FontWeight.w700, color: Color(0xFF35147D)),
                          ),
                          Text(etiquetafase,
                          style: GoogleFonts.poppins(fontSize: 14, fontWeight:  FontWeight.w600, color: Color(0xFF5245AE)),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 15),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(sesionesporciclo,
                      (i) => Container(
                        margin: EdgeInsets.symmetric(horizontal: 4),
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: i < llenos ? Color(0xFF7B5CD6) : Color(0xFFD9CCF0),
                        ),
                      )
                  ),
                ),

                if(enestudio)...[
                  SizedBox(height: 16),
                  Wrap(
                    alignment: WrapAlignment.center,
                    spacing: 8,
                    runSpacing: 4,
                    children: [
                      ...opcionesestudio.map(
                          (m) => _chip("$m min",minestudio == m, bloqueado ? null : () => _cambiarestudio(m)),
                      ),
                      _chip(espersonalizado ? "$minestudio min" : "Otro",espersonalizado, bloqueado ? null : _otrotiempo),
                    ],
                  ),
                ],

                SizedBox(height: 20),
                InkWell(
                  borderRadius: BorderRadius.circular(30),
                  onTap: corriendo ? pausar : iniciar,
                  child: Container(
                    width: double.infinity,
                    padding: EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(
                      color: Color(0xFF7B5CD6),
                      borderRadius: BorderRadius.circular(30),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0xFF7B5CD6).withOpacity(0.4),
                          blurRadius: 10,
                          offset: Offset(0, 5),
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(corriendo ? Icons.pause_rounded : Icons.play_arrow_rounded, color: Colors.white, size: 30),

                        SizedBox(width: 8),
                        Text(corriendo
                        ?"Pausar"
                            :(empezando ? "Reaundar" : "Iniciar"),
                          style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                ),

                if(empezando && !corriendo)
                  TextButton(onPressed: reiniciar,
                      child: Text("Reiniciar",
                      style: GoogleFonts.poppins(color: Color(0xFF5245AE)),
                      ),
                  ),
                if(!enestudio)
                  TextButton(onPressed: _saltardescanso,
                      child: Text("Saltar descanso",
                      style: GoogleFonts.poppins(color: Color(0xFF5245AE)),
                      ),
                  ),

                SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                        child: _CartaOpcion(
                            icono: Icons.coffee_rounded,
                            titulo: "Descanso",
                            valor: "$mindescansocorto min",
                            onTap: _cambiardescanso,
                        ),
                    ),
                  ],
                )
              ],
            ),
          )
      ),
    );
  }
}

class _CartaOpcion extends StatelessWidget{

  final IconData icono;
  final String titulo;
  final String valor;
  final VoidCallback onTap;

  const _CartaOpcion({
    required this.icono,
    required this.titulo,
    required this.valor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(22),
          boxShadow: [
            BoxShadow(
              color: Color(0xFF7957EA).withOpacity(0.15),
              blurRadius: 14,
              offset: Offset(0, 6),
            ),
          ],
        ),
        child: Row(
          children: [
            Icon(icono, color: Color(0xFF7B5CD6), size: 28),
            
            SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(titulo,
                style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w700, color: Color(0xFF35147D)),
                ),
                Text(valor,
                style: GoogleFonts.poppins(fontSize: 13, color: Color(0xFF5245AE)),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}