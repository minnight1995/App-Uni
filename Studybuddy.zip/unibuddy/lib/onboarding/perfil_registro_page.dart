
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/api.dart';
import 'package:unibuddy/cartas/carta_registro.dart';
import 'package:unibuddy/onboarding/objetivo_page.dart';
import 'package:unibuddy/widgets/widget__puntos.dart';

class PerfilRegistroPage extends StatefulWidget {
  final String token;
  final int? genero;

  const PerfilRegistroPage({
    super.key,
    required this.token,
    required this.genero,
  });

  @override
  State<PerfilRegistroPage> createState() => _PerfilRegistroPageState();
}

class _PerfilRegistroPageState extends State<PerfilRegistroPage> {
  final nombre = TextEditingController();
  final carrera = TextEditingController();
  final semestre = TextEditingController();
  final universidad = TextEditingController();

  bool cargando = false;

  void mostrar(String mensaje) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(mensaje)),
    );
  }

  @override
  void dispose() {
    nombre.dispose();
    carrera.dispose();
    semestre.dispose();
    universidad.dispose();
    super.dispose();
  }

  Future<void> guardar() async {
    if (nombre.text.trim().isEmpty ||
        carrera.text.trim().isEmpty ||
        semestre.text.trim().isEmpty) {
      mostrar('Completa los campos obligatorios');
      return;
    }

    final sem = int.tryParse(semestre.text.trim());
    if (sem == null || sem < 1 || sem > 20) {
      mostrar('Escribe tu semestre solo con números');
      return;
    }

    setState(() => cargando = true);
    final r = await guardarPerfil(
      token: widget.token,
      nombre: nombre.text.trim(),
      carrera: carrera.text.trim(),
      semestre: sem,
      universidad: universidad.text.trim(),
      genero: widget.genero,
    );
    if (!mounted) return;
    setState(() => cargando = false);

    if (r['error'] != null) {
      mostrar(r['error']);
      return;
    }
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const ObjetivoPage()));
    mostrar('¡Perfil guardado!');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF1E7FA),
      body: SafeArea(
          child: SingleChildScrollView(
              padding: EdgeInsets.all(24),
            child: Center(
              child: Column(
                children: [
                  SizedBox(height: 30),
                  Text("¡Completa tu perfil!",
                    style: GoogleFonts.fredoka(fontSize: 24, fontWeight: FontWeight.w800, color: Color(0xFF35147D)),
                  ),

                  SizedBox(height: 15),
                  Text("Cuéntame algunos datos para ayudarte mejor.",
                    textAlign: TextAlign.center,
                    style: GoogleFonts.poppins(fontSize: 16,fontWeight: FontWeight.w400, color: Color(0xFF5245AE))                    ,
                  ),

                  SizedBox(height: 160),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text("Nombre o cómo quieres que te llamen:",
                      style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w500, color: Color(0xFF5245AE)),
                    ),
                  ),
                  CartaRegistro(
                      icono: Icons.person,
                      nombre: "Ej: Ana",
                      control: nombre
                  ),

                  SizedBox(height: 12),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text("¿Qué carrera estudias?",
                      style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w500, color: Color(0xFF5245AE)),
                    ),
                  ),
                  CartaRegistro(
                      icono: Icons.work,
                      nombre: "Ej: Ingenieria multimedia",
                      control: carrera,
                  ),

                  SizedBox(height: 12),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text("¿En qué semestre estás?",
                      style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w500, color: Color(0xFF5245AE)),
                    ),
                  ),
                  CartaRegistro(
                    icono: Icons.calendar_month,
                    nombre: "Ej: 8 ",
                    control: semestre,
                  ),


                  SizedBox(height: 12),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text("Universidad (opcional)",
                      style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w500, color: Color(0xFF5245AE)),
                    ),
                  ),
                  CartaRegistro(
                    icono: Icons.assured_workload,
                    nombre: "Ej: Universidad Simón Bolivar",
                    control: universidad,
                  ),

                  SizedBox(height: 20),
                  InkWell(
                    borderRadius: BorderRadius.circular(30),
                    onTap: cargando ? null : guardar,
                    child: Container(
                      width: double.infinity,
                      padding: EdgeInsets.symmetric(vertical: 16),
                      decoration: BoxDecoration(
                        color: Color(0xFF9675E8),
                        borderRadius: BorderRadius.circular(30),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0xFF9675E8).withOpacity(0.4),
                            blurRadius: 10,
                            offset: Offset(0, 5),
                          ),
                        ],
                      ),
                      child: cargando
                          ?SizedBox(
                        height: 32,
                        child: Center(
                          child: SizedBox(
                            height: 24,
                            width: 24,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 3,
                            ),
                          ),
                        ),
                      )
                          :Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text("Continuar",
                            style: GoogleFonts.poppins(fontSize: 18,fontWeight: FontWeight.w600, color: Colors.white),
                          ),
                          SizedBox(width: 4),
                          Icon(Icons.chevron_right, color: Color(0xFF5245AE), size: 32),
                        ],
                      ),
                    ),
                  ),

                  SizedBox(height: 8),
                  Puntos(activo: 1),
                ],
              ),
            ),
          ),
      ),
    );
  }
}
