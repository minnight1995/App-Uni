
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/cartas/carta_registro.dart';
import 'package:unibuddy/onboarding/registro_page.dart';
import 'package:unibuddy/pages/home_page.dart';
import 'package:unibuddy/api.dart';

class IniciosesionPage extends StatefulWidget {
  const IniciosesionPage({super.key});

  @override
  State<IniciosesionPage> createState() => _IniciosesionPageState();
}
class _IniciosesionPageState extends State<IniciosesionPage> {
  final correo = TextEditingController();
  final contrasena = TextEditingController();

  bool recuerdame = false;
  bool cargando = false;

  void mostrar(String mensaje) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(mensaje)),
    );
  }
  Future<void> entrar() async {
    if (correo.text.trim().isEmpty || contrasena.text.isEmpty) {
      mostrar("Completa todos los campos");
      return;
    }

    setState(() => cargando = true);
    try {
      final datos = await iniciarSesion(
        correo.text.trim(),
        contrasena.text,
        recuerdame,
      );
      if (!mounted) return;

      if (datos == null) {
        mostrar("Correo o contraseña incorrectos");
        return;
      }

      await guardarToken(datos['token']);
      if (!mounted) return;

      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => HomePage()),
            (route) => false,
      );
    } catch (_) {
      if (mounted) mostrar('No se pudo conectar con el servidor');
    } finally {
      if (mounted) setState(() => cargando = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF1E7FA),
      body: SafeArea(
          child: SingleChildScrollView(
          padding: EdgeInsets.all(24),
          child: Center(
            child: Column(
              children: [
                SizedBox(height: 200),
                Text("Iniciar sesión",
                  style: GoogleFonts.fredoka(fontSize: 30, fontWeight: FontWeight.w700, color: Color(0xFF35147D)),
                ),

                SizedBox(height: 15),
                Text("¡Bienvenido de vuelta! 💜",
                  textAlign: TextAlign.center,
                  style: GoogleFonts.poppins(fontSize: 16,fontWeight: FontWeight.w500, color: Color(0xFF5245AE))                    ,
                ),

                SizedBox(height: 12),
                CartaRegistro(
                  icono: Icons.email,
                  nombre: "Correo electrónico",
                  control: correo,
                ),

                SizedBox(height: 12),
                CartaRegistro(
                  icono: Icons.lock,
                  nombre: "Contraseña",
                  control: contrasena,
                  contrasena: true,
                ),

                SizedBox(height: 8),
                Row(
                  children: [
                    Checkbox(
                      value: recuerdame,
                      onChanged: (v) => setState(() => recuerdame = v ?? false),
                      shape: CircleBorder(),
                      activeColor: Color(0xFF7B5CD6),
                    ),

                    Text("Recúerdame",
                    style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w400, color: Color(0xFF5245AE)),
                    ),
                  ],
                ),

                SizedBox(height: 24),
                InkWell(
                  borderRadius: BorderRadius.circular(30),
                  onTap: cargando ? null : entrar,
                  child: Container(
                    width: double.infinity,
                    padding: EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(
                      color: Color(0xFF9675E8),
                      borderRadius: BorderRadius.circular(30),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0xFF9675E8).withOpacity(0.4),
                          blurRadius: 10,
                          offset: Offset(0, 5),
                        ),
                      ],
                    ),
                    child: cargando
                        ?SizedBox(
                      height: 32,
                      child: Center(
                        child: SizedBox(
                          height: 24,
                          width: 24,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 3,
                          ),
                        ),
                      ),
                    )
                        :Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("Iniciar sesión",
                          style: GoogleFonts.poppins(fontSize: 18,fontWeight: FontWeight.w600, color: Colors.white),
                        ),
                        SizedBox(width: 4),
                        Icon(Icons.chevron_right, color: Color(0xFF5245AE), size: 32),
                      ],
                    ),
                  ),
                ),

                SizedBox(height: 15),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: (){
                        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => RegistroPage()));
                      },
                      child: Text.rich(
                        TextSpan(
                          children: [
                            TextSpan(
                              text:"¿Aun no tienes cuenta?",
                              style: TextStyle(color: Color(0xFF5245AE)),
                            ),
                            TextSpan(
                              text: " Registrarme",
                              style: TextStyle(color: Color(0xFFC47CCE)
                              ),
                            ),
                          ],
                        ),
                        style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w400),
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
          ),
      ),
    );
  }
}
