import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/onboarding/iniciosesion_page.dart';

class BienvenidaPage extends StatelessWidget {
  const BienvenidaPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF1E7FA),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Center(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(height: 30),
                Text("¡Bienvenido a",
                    style: GoogleFonts.fredoka(fontSize: 22, fontWeight: FontWeight.w800, color: Color(0xFF35147D))
                ),

                SizedBox(height: 12),
                Text.rich(
                  TextSpan(
                    children: [
                      TextSpan(
                        text:"Study",
                        style: TextStyle(color: Color(0xFF7957EA)),
                      ),
                      TextSpan(
                          text: "Buddy",
                          style: TextStyle(color: Color(0xFFC47CCE))
                      ),
                    ],
                  ),
                  style: GoogleFonts.fredoka(fontSize: 40, fontWeight: FontWeight.w700),
                ),

                SizedBox(height: 15),
                Text("Tu compañero de estudio para organizar y cumplir tus metas",
                  textAlign: TextAlign.center,
                  style: GoogleFonts.poppins(fontSize: 16,fontWeight: FontWeight.w400, color: Color(0xFF5245AE))                    ,
                ),

                SizedBox(height: 15),
                Container(
                  width: 315,
                  height: 315,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xFFD2BFFA),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0xFFD2BFFA),
                        blurRadius: 20,
                        offset: Offset(0, 10),
                      ),
                    ],
                  ),
                  child: ClipOval(
                    child: Image.asset(
                      "assets/images/personaje.png",
                      fit: BoxFit.cover,
                    ),
                  ),
                ),

                SizedBox(height: 15),
                Text("Personalicemos tu experiencia",
                  style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w400, color: Color(0xFF5245AE)),
                ),

                SizedBox(height: 60),
                InkWell(
                  onTap: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context) => IniciosesionPage()));
                  },
                  child: Container(
                    margin: EdgeInsets.only(bottom: 15),
                    padding: EdgeInsets.all(15),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        color: Color(0xFF9675E8),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0xFF9675E8),
                            blurRadius: 10,
                            offset: Offset(0, 5),
                          ),
                        ]
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("¡Comencemos!",
                          style: GoogleFonts.poppins(fontSize: 18,fontWeight: FontWeight.w600, color: Colors.white),
                        ),
                        SizedBox(width: 4),
                        Icon(Icons.chevron_right, color: Color(0xFF5245AE), size: 32),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
