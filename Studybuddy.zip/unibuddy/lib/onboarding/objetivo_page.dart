import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/cartas/carta_objetivo.dart';
import 'package:unibuddy/onboarding/empezar_page.dart';
import 'package:unibuddy/widgets/widget__puntos.dart';

class _Objetivo {
  final String url;
  final String titulo;
  const _Objetivo(this.url, this.titulo);
}

class ObjetivoPage extends StatefulWidget {
  const ObjetivoPage({super.key});

  @override
  State<ObjetivoPage> createState() => _ObjetivoPageState();
}

class _ObjetivoPageState extends State<ObjetivoPage> {
  final Set<int> seleccionados = {};

final List<_Objetivo> objetivos = const [
  _Objetivo("assets/images/personaje.png", "Organizar mis tareas"),
  _Objetivo("assets/images/personaje.png", "Recordar mis entregas"),
  _Objetivo("assets/images/personaje.png", "Mejorar mis hábitos de estudio"),
  _Objetivo("assets/images/personaje.png", "Administrar mi tiempo"),
  _Objetivo("assets/images/personaje.png", "Seguir mi progreso académico"),
  _Objetivo("assets/images/personaje.png", "Organizar mis apuntes"),
];

void mostrar(String mensaje) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(mensaje)),
  );
}
void alternar(int i) {
  setState(() {
    if (seleccionados.contains(i)) {
      seleccionados.remove(i);
    } else {
      seleccionados.add(i);
    }
  });
}
Widget tarjeta(int i) {
  return Expanded(
    child: InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: () => alternar(i),
      child: CartaObjetivo(
        url: objetivos[i].url,
        titulo: objetivos[i].titulo,
        seleccionado: seleccionados.contains(i),
      ),
    ),
  );
}

Widget fila(int izquierda, int derecha) {
  return SizedBox(
    height: 150,
    child: Row(
      children: [
        tarjeta(izquierda),
        SizedBox(width: 12),
        tarjeta(derecha),
      ],
    ),
  );
}


  @override
  Widget build(BuildContext context) {
  final cantidad = seleccionados.length;
    return Scaffold(
      backgroundColor: Color(0xFFF1E7FA),
      body: SafeArea(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Center(
              child: Column(
                children: [
                  SizedBox(height: 30),
                  Text("¿En qué quieres que te ayude?",
                    style: GoogleFonts.fredoka(fontSize: 24, fontWeight: FontWeight.w800, color: Color(0xFF35147D)),
                  ),

                  SizedBox(height: 15),
                  Text("Selecciona tus objetivos para comenzar.",
                    textAlign: TextAlign.center,
                    style: GoogleFonts.poppins(fontSize: 16,fontWeight: FontWeight.w400, color: Color(0xFF5245AE))                    ,
                  ),

                  SizedBox(height: 30),
                  Expanded(
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            fila(0, 1),
                            fila(2, 3),
                            fila(4, 5),
                          ],
                        ),
                      ),
                  ),

                  SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if(cantidad > 0)
                        Padding(
                            padding: EdgeInsets.only(right: 6),
                          child: Icon(Icons.check_circle, color:  Color(0xFF5245AE), size: 20),
                        ),
                      Text(cantidad == 1
                      ? " 1 objetivo seleccionado"
                          :" $cantidad objetivos seleccionados",
                        style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w400, color: Color(0xFF35147D)),
                      ),
                    ],
                  ),

                  SizedBox(height: 12),
                  InkWell(
                    borderRadius: BorderRadius.circular(30),
                    onTap: (){
                      if(seleccionados.isEmpty){
                        mostrar("Elige al menos un objetivo");
                        return;
                      }
                      Navigator.push(context, MaterialPageRoute(builder: (context) => EmpezarPage()));
                    },
                    child: Container(
                      width: double.infinity,
                      padding: EdgeInsets.symmetric(vertical: 15),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(30),
                          color: Color(0xFF9675E8),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0xFF9675E8),
                              blurRadius: 10,
                              offset: Offset(0, 5),
                            ),
                          ]
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text("Crear mi StudyBuddy",
                            style: GoogleFonts.poppins(fontSize: 18,fontWeight: FontWeight.w600, color: Colors.white),
                          ),
                          SizedBox(width: 2),
                          Icon(Icons.chevron_right, color: Color(0xFF5245AE), size: 32),
                        ],
                      ),
                    ),
                  ),

                  SizedBox(height: 8),
                  Puntos(activo: 2),
                ],
              ),
            ),
          )
      ),
    );
  }
}
