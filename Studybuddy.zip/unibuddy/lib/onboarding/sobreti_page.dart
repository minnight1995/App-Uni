
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/cartas/carta_genero.dart';
import 'package:unibuddy/onboarding/perfil_registro_page.dart';
import 'package:unibuddy/widgets/widget__puntos.dart';

class SobretiPage extends StatefulWidget {
  final String token;
  const SobretiPage({
    super.key,
    required this.token
  });

  @override
  State<SobretiPage> createState() => _SobretiPageState();
}
class _SobretiPageState extends State<SobretiPage> {
  int? seleccionado;

  void mostrar(String mensaje) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(mensaje)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF1E7FA),
      body: SafeArea(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Center(
              child: Column(
                children: [
                  SizedBox(height: 30),
                  Text("Cuéntanos sobre ti",
                    style: GoogleFonts.fredoka(fontSize: 24, fontWeight: FontWeight.w800, color: Color(0xFF35147D)),
                  ),

                  SizedBox(height: 15),
                  Text("Selecciona tu género para personalizar tu experiencia.",
                    textAlign: TextAlign.center,
                    style: GoogleFonts.poppins(fontSize: 16,fontWeight: FontWeight.w400, color: Color(0xFF5245AE))                    ,
                  ),

                  SizedBox(height: 40),
                  SizedBox(
                    height: 400,
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: [
                            SizedBox(
                              width: 250,
                              child: Cartagenero(
                                  url: "assets/images/hombre.png",
                                  titulo: "Hombre",
                                  seleccionado: seleccionado == 0,
                                  onChanged: (valor) => setState(() => seleccionado = valor == true ? 0 : null),
                              ),
                            ),

                            SizedBox(width: 12),
                            SizedBox(
                              width: 250,
                              child: Cartagenero(
                                url: "assets/images/mujer.png",
                                titulo: "Mujer",
                                seleccionado: seleccionado == 1,
                                onChanged: (valor) => setState(() => seleccionado = valor == true ? 1 : null),
                              ),
                            ),

                            SizedBox(width: 12),
                            SizedBox(
                              width: 250,
                              child: Cartagenero(
                                url: "assets/images/buddy.png",
                                titulo: "Buddy",
                                seleccionado: seleccionado == 2,
                                onChanged: (valor) => setState(() => seleccionado = valor == true ? 2 : null),
                              ),
                            ),
                          ],
                        ),
                      ),
                  ),

                  SizedBox(height: 60),
                  InkWell(
                    onTap: (){
                      if(seleccionado == null){
                        mostrar("Selecciona una opción para continuar");
                        return;
                      }
                      Navigator.push(context, MaterialPageRoute(builder: (context) => PerfilRegistroPage(
                          token: widget.token,
                          genero: seleccionado))
                      );
                    },
                    child: Container(
                      margin: EdgeInsets.only(bottom: 15),
                      padding: EdgeInsets.all(15),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(30),
                          color: Color(0xFF9675E8),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0xFF9675E8),
                              blurRadius: 10,
                              offset: Offset(0, 5),
                            ),
                          ]
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text("¡Continuar!",
                            style: GoogleFonts.poppins(fontSize: 18,fontWeight: FontWeight.w600, color: Colors.white),
                          ),
                          SizedBox(width: 2),
                          Icon(Icons.chevron_right, color: Color(0xFF5245AE), size: 32),
                        ],
                      ),
                    ),
                  ),

                  SizedBox(height: 8),
                  Puntos(activo: 0),
                ],
              ),
            ),
          ),
      ),
    );
  }
}
