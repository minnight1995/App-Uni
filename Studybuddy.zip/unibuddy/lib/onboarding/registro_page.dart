import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/cartas/carta_registro.dart';
import 'package:unibuddy/onboarding/iniciosesion_page.dart';
import 'package:unibuddy/api.dart';
import 'package:unibuddy/onboarding/sobreti_page.dart';

class RegistroPage extends StatefulWidget {
  const RegistroPage({super.key});

  @override
  State<RegistroPage> createState() => _RegistroPageState();
}
class _RegistroPageState extends State<RegistroPage> {
  final nombre = TextEditingController();
  final correo = TextEditingController();
  final contrasena = TextEditingController();
  final confirmar = TextEditingController();

  bool cargando = false;

  void mostrar(String mensaje) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(mensaje)),
    );
  }
  @override
  void dispose() {
    nombre.dispose();
    correo.dispose();
    contrasena.dispose();
    confirmar.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF1E7FA),
      body: SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.all(24),
            child: Center(
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      InkWell(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Icon(Icons.arrow_back_ios_new, color: Color(0xFF4A2A6B)),
                      ),
                    ],
                  ),

                  SizedBox(height: 200),
                  Text("Crear una cuenta",
                    style: GoogleFonts.fredoka(fontSize: 30, fontWeight: FontWeight.w700, color: Color(0xFF35147D)),
                  ),

                  SizedBox(height: 15),
                  Text("Únete a StudyBuddy y comienza a organizar tu vida de estudiante",
                    textAlign: TextAlign.center,
                    style: GoogleFonts.poppins(fontSize: 16,fontWeight: FontWeight.w500, color: Color(0xFF5245AE))                    ,
                  ),

                  SizedBox(height: 15),
                  CartaRegistro(
                      icono: Icons.person,
                      nombre: "Nombre completo",
                      control: nombre,
                  ),

                  SizedBox(height: 12),
                  CartaRegistro(
                    icono: Icons.email,
                    nombre: "Correo electrónico",
                    control: correo,
                  ),

                  SizedBox(height: 12),
                  CartaRegistro(
                    icono: Icons.lock,
                    nombre: "Contraseña",
                    control: contrasena,
                    contrasena: true,
                  ),

                  SizedBox(height: 12),
                  CartaRegistro(
                    icono: Icons.lock,
                    nombre: "Confirmar contraseña",
                    control: confirmar,
                    contrasena: true,
                  ),
                  SizedBox(height: 24),
                  InkWell(
                    borderRadius: BorderRadius.circular(30),
                    onTap: cargando ? null : () async {
                      if (nombre.text.trim().isEmpty ||
                          correo.text.trim().isEmpty ||
                          contrasena.text.isEmpty) {
                        mostrar('Completa todos los campos');
                        return;
                      }
                      if(!correo.text.contains("@")){
                        mostrar("Escribe un correo válido");
                        return;
                      }
                      if(contrasena.text.length < 6){
                        mostrar("La contraseña debe tener al menos 6 caracteres");
                        return;
                      }
                      if (contrasena.text != confirmar.text) {
                        mostrar('Las contraseñas no coinciden');
                        return;
                      }
                      setState(() => cargando = true);
                      final r = await registrarUsuario(
                          nombre.text.trim(),
                          correo.text.trim(),
                          contrasena.text);
                      if(!mounted) return;
                      setState(() => cargando = false);
                      if(r["error"] != null){
                        mostrar(r["error"]);
                        return;
                      }

                      Navigator.pushReplacement(
                        context, MaterialPageRoute(builder: (_) => SobretiPage(token: r['token'] as String),),
                      );
                    },
                    child: Container(
                      width: double.infinity,
                      padding: EdgeInsets.symmetric(vertical: 16),
                      decoration: BoxDecoration(
                        color: Color(0xFF9675E8),
                        borderRadius: BorderRadius.circular(30),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0xFF9675E8).withOpacity(0.4),
                            blurRadius: 10,
                            offset: Offset(0, 5),
                          ),
                        ],
                      ),
                      child: cargando
                      ?SizedBox(
                        height: 32,
                        child: Center(
                          child: SizedBox(
                            height: 24,
                            width: 24,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 3,
                            ),
                          ),
                        ),
                      )
                          :Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text("Registrarme",
                            style: GoogleFonts.poppins(fontSize: 18,fontWeight: FontWeight.w600, color: Colors.white),
                          ),
                          SizedBox(width: 4),
                          Icon(Icons.chevron_right, color: Color(0xFF5245AE), size: 32),
                        ],
                      ),
                    ),
                  ),

                  SizedBox(height: 15),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      InkWell(
                        onTap: (){
                          Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => IniciosesionPage()));
                        },
                        child: Text.rich(
                          TextSpan(
                            children: [
                              TextSpan(
                                text:"¿Ya tienes una cuenta?",
                                style: TextStyle(color: Color(0xFF5245AE)),
                              ),
                              TextSpan(
                                text: " Iniciar sesión",
                                style: TextStyle(color: Color(0xFFC47CCE)
                                ),
                              ),
                            ],
                          ),
                          style: GoogleFonts.fredoka(fontSize: 14, fontWeight: FontWeight.w400),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),
      ),
    );
  }
}
