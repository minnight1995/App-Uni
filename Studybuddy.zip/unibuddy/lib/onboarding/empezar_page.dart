
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unibuddy/pages/home_page.dart';

class EmpezarPage extends StatelessWidget {
  const EmpezarPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Container(
            width: double.infinity,
            height: double.infinity,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color(0xFF7957EA),
                  Colors.white,
                  ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Center(
              child: SizedBox(
                width: 300,
                height: 250,
                child: Stack(
                  clipBehavior: Clip.none,
                  alignment: Alignment.center,
                  children: [
                  Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(30),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0xFF7957EA).withOpacity(0.25),
                        blurRadius: 20,
                        offset: Offset(0, 10),
                      )
                    ]
                  ),
                    child: Column(
                      children: [
                        SizedBox(height: 30),
                        Text("¡Listo para empezar!",
                          style: GoogleFonts.fredoka(fontSize: 24, fontWeight: FontWeight.w800, color: Color(0xFF35147D)),
                        ),

                        SizedBox(height: 15),
                        Text.rich(
                          TextSpan(
                            children: [
                              TextSpan(
                                text:"Ahora ya formas parte de ",
                                style: TextStyle(color: Color(0xFF7957EA)),
                              ),
                              TextSpan(
                                  text: "¡StudyBuddy ✨!",
                                  style: TextStyle(color: Color(0xFF7957EA), fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                          style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w400),
                          textAlign: TextAlign.center,
                        ),

                        SizedBox(height: 40),
                        InkWell(
                          borderRadius: BorderRadius.circular(30),
                          onTap: (){
                            Navigator.pushAndRemoveUntil(context,
                                MaterialPageRoute(builder: (_) => HomePage()),
                                ((route) => false)
                            );
                          },
                          child: Container(
                            width: 250,
                            padding: EdgeInsets.symmetric(vertical: 12),
                            decoration: BoxDecoration(
                              color: Color(0xFF9675E8),
                              borderRadius: BorderRadius.circular(30),
                              boxShadow: [
                                BoxShadow(
                                    color: Color(0xFF9675E8).withOpacity(0.4),
                                    blurRadius: 10,
                                    offset: Offset(0, 5),
                                )
                              ]
                            ),
                            child: Center(
                              child:Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text("¡Vamos!",
                                  style: GoogleFonts.poppins(fontSize: 18,fontWeight: FontWeight.w600, color: Colors.white),
                                ),
                                SizedBox(width: 2),
                                Icon(Icons.chevron_right, color: Color(0xFF5245AE), size: 32),
                              ],
                              ),
                            ),
                            ),
                          ),
                      ],
                    ),
                ),
                ],
                ),
              ),
            ),
          ),
      ),
    );
  }
}
